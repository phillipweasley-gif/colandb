# Changelog — Community Events Calendar

Custom WordPress plugin. Not a git repo — this file is the change history in lieu of a commit log. Versions follow semver: PATCH = fixes, MINOR = new backward-compatible features, MAJOR = breaking changes (none yet).

*Reconstructed from developer notes/memory and cross-checked against the 1.6.2 source (August 2026) — every technical claim below (the `!important` button rules, the `cec_card_thumb` 600×600 non-crop, the calendar grid's `minmax(0, 1fr)` fix, the 700px list-view breakpoint, the `cec-plugin-page` body class, the token hashing/expiry) was verified line-for-line against the actual code. This is now the authoritative version history — see `TECHNICAL_BRIEF.md` §8.*

---

## 1.47.1

**Fix: events with no end time were missing from the calendar** (owner, 2026-11-03: "I published the events but they're not showing in the calendar"; "If there's no end time there needs to be a filler or placeholder for it as TBD so it shows. Or however we can make that happen.").

- **Cause.** An event saved with an empty end (`_cec_end` = `''`) instead of no end at all matched neither branch of the month-view and upcoming-list queries ("ends on or after …" / "no end, starts on or after …"). It still had its own page and showed under /events/, but not on the calendar or in the upcoming lists.
  - The forms save an empty end when the field is left blank, and so did the 1.47.0 intake API.
  - On colandb.com five published events were hidden: The Lotus Underground third Friday, Monsterfucker Ball, Poker & Cigars For A Cause, NEO's Step Down Party, and the Mr. & Ms. Cleveland Leather 2027 Contest. Their empty ends were removed by hand on 2026-11-03 so they showed at once.
- **Fix.** `CEC_Event_Helper::filter_end_meta()` (already on every save of `_cec_end`) now deletes the end instead of saving an empty one. This covers all five forms, imports, repeating dates and the intake API. No placeholder value is needed: an event with no end time is treated as ending when it starts, as before.
- **One-time repair** on upgrade (`cec_migrated_1471_empty_ends`) removes any empty ends left and records which events it fixed.
- No change to the month view's markup, so no snapshot comparison was needed.

**Verified** in the local WordPress kit:
- `tests/ends-e2e.sh` 24/24, 6 of them new:
  - an empty end is not saved;
  - a start-only event shows in its month and in the upcoming list;
  - old data with an empty end is hidden, as it was on colandb.com;
  - the upgrade repair removes it and lists the event;
  - a real end is still saved.
- Regression suites: import 30/30, series 13/13, recurrence 5/5, telegram-intake 100/100, form-cache 36/36.

## 1.47.0

**Intake API for the Telegram event intake** (owner, 2026-11-03: a Telegram-to-calendar intake bot that submits events "for editorial review. Do not publish events publicly without human approval"). The calendar had no way for code to add an event except its five forms, so this is the smallest addition that lets the new `colandb-telegram-intake` plugin use the calendar's own rules. New `includes/class-cec-intake-api.php`:

- **`cec_intake_create_event( $fields )`** creates a **pending** event only. Nothing it does can publish, whatever the auto-publish setting says: it checks the status again before returning. It applies the same checks as the forms:
  - the allowed admission, location and time values;
  - IANA timezones;
  - existing Event Type terms only;
  - plain price amounts, and "paid" can't be 0;
  - http(s) links only, checked by format without a DNS lookup;
  - `Y-m-d\TH:i` dates.
- **`cec_intake_update_event( $id, $fields )`** changes only the fields given, and only while the event is pending or in review. Once it's published, scheduled, private or rejected (draft), the update is refused and the caller must send it to an editor.
- **`cec_intake_add_source( $id, $url, $note )`** records another source post on an event (`_cec_intake_source_url`, one row per source; `_cec_source_url` keeps the first). It changes nothing else.
- **`cec_intake_event_fields()`** and **`cec_intake_candidates()`** let the intake's duplicate check see every event except trashed ones (published, pending, rejected, past, cancelled), by date window or by any link on file.
- **Editor notes.** `_cec_intake_notes` and the source links show above the event preview in wp-admin and on the dashboard edit screen ("Imported automatically from a Telegram post. Check everything before approving…").
- **Shared save routine.** `CEC_Event_Helper::save_phase1a_fields( $post_id, $source = null )` now accepts the fields as an array (read like `$_POST`, so slashed), so the API saves through exactly the forms' code. With no second argument it behaves as before.
- **Audit log.** New entries "Submitted by the Telegram intake", "Updated from an edited source post" and "Another source post linked". Action labels are now filterable (`cec_audit_action_labels`).

**Verified** in the local WordPress kit:
- `tests/telegram-intake-e2e.sh`: 63/63, exercising the API through the intake plugin, including pending-only with auto-publish on, refused updates after publishing, and several sources on one event;
- regression suites: import 30/30, ends 18/18, series 13/13, recurrence 5/5, form-cache 36/36.

No month-view change, so no snapshot comparison was needed.

## 1.46.1

**Pages with forms are never cached, and an expired form still works for signed-out visitors** (found on colandb.com, 2026-10-21: the host's CDN, Elementor Hosting, sends `cache-control: public, max-age=300, s-maxage=604800` and served `/log-in-3/`, `/create-an-account-3/`, `/volunteer/` and `/submit-organization/` from its cache, `ec-cdn-status: hit`, query strings included).

- **Why it mattered:** each form carries a WordPress nonce, which for a signed-out visitor lasts only 12–24 hours. A page cached for up to 7 days hands out a dead nonce, and every handler refused it: sign-in said "Incorrect username/email or password", sign-up "Something went wrong", the volunteer and subscribe forms "Please fill in…", event submission "There was a problem", and edit-link requests and guest edits silently did nothing. A cached page could also show one visitor's "Thanks!" or error to the next. (The organization form already had no nonce for signed-out visitors, so it kept working, but its page was cached too.)
- **Never cached** (`includes/class-cec-no-cache.php`, new `CEC_No_Cache`, same treatment as Community Member Planning 0.32.1): on `template_redirect`, a page whose content or Elementor data has `[cec_login]`, `[cec_register]`, `[cec_submit_event]` (or its Elementor widget), `[cec_manage_submission]`, `[cec_subscribe]`, `[cec_volunteer_form]` (shortcode or widget), `[cec_submit_org]`, `[cec_my_events]`, `[cec_admin_dashboard]` or `[cec_meeting_admin]` defines `DONOTCACHEPAGE`, calls `nocache_headers()`, removes `ec-cdn-cache-control` and sends `Cache-Control: no-store, no-cache, must-revalidate, max-age=0, private`. Each form also calls it while rendering, for a form placed somewhere the page check can't see. The list is filterable (`cec_no_cache_shortcodes`). The meeting portal's own `nocache_headers()` (1.46.0), which left the CDN hint in place, is replaced by this. Public fundraising and meeting-notes pages have no form and stay cached.
- **Expired nonces accepted when signed out** (`CEC_No_Cache::form_nonce_ok()`), as a second line of defence: a valid nonce always passes; a signed-in visitor still needs a valid one; a signed-out visitor gets through if the form sent a nonce at all. Used only on forms with other protection: sign-in (the password; WordPress's own `wp-login.php` has no nonce either), sign-up, volunteer and subscribe (honeypots; subscribing also needs the emailed confirmation), edit-link requests (honeypot, a 5-minute limit per email, same answer either way), guest edits (the secret edit link) and event submission (the approval queue, and a new honeypot).
- **Event submission honeypot:** the form now has the hidden "leave this empty" field the other forms have; a filled one looks like success and saves nothing.
- **Guest edit links opened a 404** (found while testing this, then checked read-only on colandb.com: `/manage-my-submission-2/?cec_event=1073&cec_token=x` answers 404). The link's `cec_event` is also the event post type's query var, so WordPress looked for an event with that slug. Every edit link emailed to a guest submitter was broken. `CEC_Guest_Edit::keep_edit_link_on_page()` (`request` filter) drops the event lookup when a page is asked for with `cec_token`; existing links start working, with no change to their format.
- **Verification** (local WordPress test kit, Linux, PHP 8.3):
  - New `tests/form-cache-e2e.sh` 36/36: with a test must-use plugin adding the host's `ec-cdn-cache-control` header, all nine form pages and an Elementor-only page send `no-store` with no hint, while a plain page, the fundraising page and the home page keep it; signed out, a nonce made 2 days ago still signs up, signs in, volunteers, subscribes (unconfirmed), requests an edit link, submits an event to the queue and withdraws one by its edit link; honeypots, a missing nonce, a wrong password, a wrong edit link and a signed-in member's expired nonce are still refused; a fresh nonce works as before; edit links open the form with plain and pretty permalinks and aren't cached; no PHP warnings. Against 1.46.0 the same suite fails 24 checks.
  - All other events-plugin suites still pass: calendar 73, meetings 27, fundraisers 21, sign-up date of birth 34, org 147, import 30, series 13, ends 18, recurrence 5. Month view untouched (`CEC_Month_Grid` not changed).
  - `php -l` on every changed file.
- **To check on live after updating** (read-only): `curl -sD - -o /dev/null "https://colandb.com/log-in-3/?probe=$RANDOM"` twice; the second must not say `ec-cdn-status: hit` and must send `no-store`. Same for `/create-an-account-3/`, `/volunteer/`, `/submit-organization/`. An edit-link address with a made-up token should show "This link is invalid or has expired" instead of a 404. Pages already in the CDN cache may need the CDN cache cleared once (Elementor Hosting → Clear cache) to drop old copies.

---

## 1.46.0

**Public fundraising tracker and meeting notes** (owner, 2026-10-18: "a fundraising tracker … visible to the public and can be listed on a page under the About COL&B"; "another page for the secretary to submit meeting notes in via an admin portal kind of like how the calendar is managed". Chose: the site team enters donations, several fundraisers at once, totals only (no donor names), a donate link per fundraiser; meeting notes public once approved, a Secretary role, with attendance, motions, files and Draft/Approved).

**Fundraisers** (`includes/class-cec-fundraisers.php`, `assets/css/fundraisers.css`)
- **Events → Fundraisers** in wp-admin (site administrators): title, description, photo, goal, optional start and end dates, optional organization or titleholder it's for, a donate link with its button text, and "other ways to give".
- **Donations (private)** box: each donation's amount, date, how it was given (online, cash, Venmo, Cash App, PayPal, check, other) and a private note; three empty rows each time; Remove boxes. Amounts like "$1,250.50" are accepted; anything that isn't an amount, and zero, is skipped. The total and count are cached (`_cec_fr_raised`, `_cec_fr_count`).
- **Public, totals only:** `[cec_fundraisers]` shows current and upcoming fundraisers (ending soonest first), then **Completed fundraisers**. Each card: photo, title, "For <group>" (linked), "Through …" / "Starts …" / "Ended …", a progress bar (`role="progressbar"`, with "$450 raised of $1,000 goal" for screen readers), "$450 raised of $1,000 goal · 45% · 12 donations", "Goal reached. Thank you!" at 100%+, the description, the donate button (new tab) and other ways to give. Completed ones have no button. Donation dates, methods, notes and individual amounts are never output. `show="current"` / `show="ended"`; `[cec_fundraiser id="123"]` for one card. Drafts aren't shown.
- A published **Fundraising** page with `[cec_fundraisers]` is created on upgrade and linked under Events → Settings, like the plugin's other pages. Saving or trashing a fundraiser re-saves the pages showing it so the CDN serves the new totals.

**Meeting notes** (`includes/class-cec-meetings.php`, `assets/css/meetings.css`)
- **Secretary role** (`cec_secretary`, capability `cec_manage_meetings`; administrators have it too). Assign it under Users. A Secretary is sent from wp-admin to the portal, and gets **Meeting Notes Admin** in the signed-in menu (via Community Member Planning's `cmp_account_bar_items` filter, so no change to that plugin).
- **Portal** `[cec_meeting_admin]` on the new **Meeting Notes Admin** page: a list (date, meeting, Draft/Approved, Edit, Delete with a confirm), and the form: meeting date (required), type (General / Board / Special / Committee / Other), title (empty = "General Meeting, Oct 14, 2026"), the notes in a simple editor, organizations present (organizations, not titleholders) and others present, motions (text, moved by, seconded by, result Passed/Failed/Tabled/Withdrawn, votes for/against/abstaining; two empty each time; clear the text to remove), files (PDF, Word, OpenDocument, text, JPEG, PNG, up to 10 MB each; others are refused and named; Remove deletes the file), and Draft / Approved. Signed out it asks to sign in; others are told only the Secretary and administrators can use it. Never cached.
- **Public** `[cec_meeting_notes]` on the new **Meeting Notes** page: approved notes only, newest first, grouped by year, each collapsible (the newest open) with Present, Notes, Motions ("Moved by …, seconded by …. Passed (6 for, 0 against, 1 abstaining)") and Files. Approving, editing or deleting re-saves the page for the CDN. Deleting moves notes to the trash (restorable).
- Attached files live in the media library: their links work as soon as they're uploaded, before the notes are approved, though nothing links to a draft's files.

**After updating:** add **Fundraising** and **Meeting Notes** under **About COL&B** in the site menu; give the Secretary the Secretary role. Meeting Notes Admin, like Calendar Admin, needn't be in the menu.

- **Verification** (local WordPress test kit, macOS, PHP 8.4):
  - New `tests/fundraisers-e2e.sh` 21/21: the page; adding a fundraiser and donations through the real wp-admin edit screen (amount parsing, skipped rows, date order); the public card (numbers, accessible bar, button, other ways to give); **no private details on the page**; removing a donation; over the goal; upcoming / completed / drafts / order; the single card and `show`; a member can't edit; no warnings.
  - New `tests/meetings-e2e.sh` 27/27: the pages; signed out / member / Secretary access; the menu link; wp-admin sending the Secretary to the portal; the form; a draft with an empty title, a stripped `<script>`, organizations (titleholder ignored), motions (empty dropped), a PDF attached and an .exe refused; drafts not public; editing; approving; the public page (years, order, open newest, type, present, formatted notes, motions with votes, the PDF); removing a file; an invalid date; a member can't save even with a nonce; deleting; the portal never cached; no warnings.
  - Screenshots on the test site (desktop and phone) of the Fundraising page, the Meeting Notes page, the portal list and the form.
  - All other suites still pass: calendar 73, import 30, org 147, series 13, ends 18, recurrence 5. `php -l` on every changed file.
  - Mac setup as before (router script, port 8898, `timeout`/`sed`/`wc` stand-ins; nothing committed).

---

## 1.45.3

**Events that end before they start** (owner, 2026-10-15: after 1.45.2 put the "Crate Training" series back on its own Tuesdays, its later dates read "Tue, Dec 8, 2026 7:00 pm – Tue, Nov 10, 2026 12:00 am"; "House of Pan Fall Zoo Adventure" ends in 2006. Chose: past-midnight ends become the next day, earlier dates are refused, plus an in-place repair).

- **Cause:** no form checked that the end is after the start. "Crate Training" was entered as 7:00 PM to 12:00 AM on **Nov 10** (midnight at the start of that day, not the end), and its other dates copied that end; while 1.45.1's bug kept them all on Nov 10 it only looked odd. Calendar apps subscribed to the .ics feed may skip events whose end is before their start.
- **The rule, everywhere an end is saved** (the five edit forms, imports, repeating dates; `CEC_Event_Helper::normalize_end()` on the `add/update_post_metadata` filters):
  - same date, earlier time ("7 PM to 12 AM", "8 PM to 2 AM"): the event runs past midnight, so the end is saved as the next day;
  - an earlier date: no end is kept (a safety net; see below).
- **On the front-end forms** (Submit an Event, Calendar Admin, My Events, Manage My Submission): an end on an earlier date than the start is refused before sending, with "The end is on an earlier date than the start. Check the end date. …", and a same-day earlier time shows "Ends after midnight, on the next day." (`frontend.js`).
- **Repeating series:** each date's end now follows its own start (the series' first date is fixed by the rule, so the length is right).
- **Repair, once on upgrade** (`CEC_Migrations::fix_event_ends()`, option `cec_migrated_1453_event_ends` with `fixed` / `left` ids):
  - a single event or a series' first date whose end is earlier the same day: moved to the next day;
  - a series' other dates: each ends the same length of time after its own start as the first date does;
  - an end on an earlier date (the 2006 typo): **left for a person to correct** and listed under `left`. Each fix gets an audit log entry (`event_end_fixed`).
  - On colandb.com this should fix the six "Crate Training" dates (#921, #923–#927: each ends at midnight after its Tuesday) and list "House of Pan Fall Zoo Adventure" (#1044) to correct by hand.
- **Verification** (local WordPress test kit, macOS, PHP 8.4):
  - New `tests/ends-e2e.sh`: 18/18 (the rule; saving through the meta filter; a wp-admin save over HTTP storing 8 PM–2 AM as 2 AM the next day, and the event page showing it; a 7 PM–12 AM series' dates each ending at midnight after their own Tuesday; the repair on data shaped like the live events, leaving the 2006 typo listed and a correct event untouched, running once from the upgrade; the .ics feed with no end before a start). On 1.45.2 its rule and save checks fail.
  - Headless Chrome on the Submit an Event form: the past-midnight note shows, a 2006 end is refused and the form isn't sent, a normal end shows nothing.
  - `tests/series-e2e.sh` 13/13, `tests/recurrence-e2e.sh` 5/5, `tests/calendar-e2e.sh` 73/73, `tests/import-e2e.sh` 30/30, `tests/org-e2e.sh` 147/147. No plugin warnings. `php -l` on every changed file.
  - Mac setup as before (router script, port 8898, `timeout` stand-in; nothing committed).

---

## 1.45.2

**Automatic, in-place repair of series whose dates were collapsed before 1.45.1** (owner, 2026-10-15: "Crate Training: A Mosh-101 Course/ Vinyl Record Night" shows six times on Tue Nov 10; chose this over 1.45.1's manual fix).

- 1.45.1 stops a wp-admin save from moving a series' dates onto its first date, but a series already collapsed stays that way, and its fix ("change Repeat until and Update") deletes the later dates and creates new ones (new pages and links, RSVPs on them lost).
- **On upgrade, once:** `CEC_Recurrence::repair_collapsed_dates()` finds any series with a date that starts at the same moment as its first date (impossible for a healthy series), recomputes the schedule from the series' own rule, and gives each existing date back its own start and end, oldest first (the order they were created in), **in place**: same posts, links and RSVPs. Each repaired date gets an audit log entry (`event_series_date_repaired`). Gated on the option `cec_migrated_1452_series_dates`, which records when it ran and which series it fixed. Healthy series are untouched.
- On colandb.com this should repair one series (#921, dates #923–#927); a read-only check of the live calendar feeds on 2026-10-15 found no others. **No manual step is needed after updating.**
- **Verification** (local WordPress test kit, macOS, PHP 8.4):
  - New `tests/series-e2e.sh`: 13/13. Builds a 2nd-Tuesday series and saves it through wp-admin over real HTTP (the block editor's meta box save) to check 1.45.1 keeps the dates; collapses a series the way it happened live and checks the repair restores the same 2nd Tuesdays and end times on the same posts, leaves a healthy series alone, and runs once from the upgrade.
  - `tests/recurrence-e2e.sh` (1.45.1) 5/5, `tests/calendar-e2e.sh` 73/73, `tests/import-e2e.sh` 30/30. No plugin warnings. `php -l` on the changed files.
  - Mac setup: a local router script and port 8898, and a small `timeout` stand-in (macOS has none) for `recurrence-e2e.sh`; nothing committed.

---

## 1.45.1

**A recurring event approved in wp-admin showed every date on the first day** (owner, 2026-10-14: "Why are there repeat events for this one event that was approved?", about "Crate Training: A Mosh-101 Course/ Vinyl Record Night", listed six times on Tue Nov 10).

- **Cause:** the event is a monthly "2nd Tuesday" series (Nov 10 plus five more dates, Dec 8 to Apr 13, each its own post). Publishing a series root cascades the status to its dates, and each of those updates fired the wp-admin meta-box save again with the root's form still in `$_POST`, so every date was saved with the root's start. All six then sat on Nov 10. Any series approved or edited from the wp-admin edit screen was affected; the front-end dashboard's Approve and edit weren't.
- **Worse, same cause:** changing a series' schedule (start, "Repeat until", the rule) in wp-admin regenerated the dates, and each new date ran the meta-box save as a series root of its own, creating dates of dates until PHP stopped the request (527 posts in two minutes in the test kit).
- **Fix:** `CEC_Meta_Boxes::save()` now saves only the post the edit screen submitted (`post_ID`), and ignores saves nested inside its own run. `CEC_Recurrence::generate_occurrences()` sets `_cec_recurrence_parent_id` during the insert, so a regenerated date is an occurrence from its first hook: before, each published regenerated date sent subscribers its own "New event" email.
- **Live data:** the six posts are not copies; they are the series with wrong dates. Saving the series again does not repair them on its own (an unchanged schedule only syncs content). Once 1.45.1 is live, change its "Repeat until" in wp-admin and Update: the five later dates are rebuilt on their own days. Don't change the schedule in wp-admin before 1.45.1 is live (runaway above).
- **Verification** (local WordPress test kit, Linux, PHP 8.3):
  - New `tests/recurrence-e2e.sh`: 5/5. A submitted pending monthly series published with the form wp-admin sends keeps each date's day; only the series triggers a "New event" email; changing "Repeat until" regenerates three dates once, with no per-date email. On 1.45.0 the publish check fails (all dates on the first) and the run never finishes (runaway).
  - `tests/import-e2e.sh` 30/30 and `tests/calendar-e2e.sh` 73/73 still pass. No plugin warnings in `debug.log`. `php -l` on every changed PHP file. No month-grid change, so no `snap.php` comparison.

---

## 1.45.0

**Import events for an organizer, and "Copy for Facebook, FetLife or Telegram"** (owner, 2026-10-13, from a member asking: "Is there a way to import events already posted to other socials … As an organizer, it is exhausting having to cross post to so many different formats." Owner: "build both").

- **Import for an organizer** (Calendar Admin → Import):
  - Takes a **.csv spreadsheet** as well as an .ics calendar file. One event per row; column names in the first row, matched loosely: Title (or Subject / Name / Event), Start (or Start Date + Start Time), End (or End Date + End Time), All Day, Description, Location (or Venue / Address), URL (or Link), Price (or Cost). Outlook's export columns work as-is. Dates like 2026-10-16 19:00, 10/16/2026 7:00 PM or Oct 16, 2026 7pm, in the site's time zone; a date with no time is all-day. Price: empty = Price Not Posted, "Free" or 0 = Free, one amount = Paid at that amount, anything else (a range) = Not Posted with a note. Rows with no title or an unreadable date are skipped and listed. A "Download a template" link gives the layout.
  - **Organization or titleholder** (optional): the events are linked to that group, so they show on its page and under its name, and its name is the host when the file doesn't give one.
  - **Managed by** (optional): a member's username or email makes them the events' author (they appear in that member's My Events, with their email as the submitter email); an email address with no account owns them like a guest submission (no author, submitter email set), so that person manages them through Manage My Submission. An unknown username stops the import with a clear message and nothing created.
  - **Email them** (on by default): the owner gets a list of the events with links and where to manage them.
  - Re-uploading the same CSV with "update previously imported" updates instead of duplicating (each row's ID comes from its title and start).
- **Copy for Facebook, FetLife or Telegram** on every event page: the event written up as plain text (title, a CANCELLED/POSTPONED line when it applies, When, Where, Cost, Hosted by, the description with its paragraph breaks, "Details and RSVP: <link>") in a read-only box with a **Copy text** button, so organizers post once on COL&B and paste it everywhere else. No HTML or emoji, so it pastes cleanly on every platform. `CEC_Event_Helper::post_text()`.
- **Fixes found along the way:**
  - The import summary ("3 events imported", per-event notes) never showed after an import: its token was mixed case and was read back through `sanitize_key()`, which lowercases. Now lowercase.
  - Imported events were published before their date, place and group were saved, so the "New event" email to subscribers went out without the date and place, and a group's subscribers weren't matched at all. Events are now saved as drafts, filled in, then published.
  - An .ics time without a trailing "Z" logged "Undefined array key 7".
- **Verification** (local WordPress test kit, macOS, PHP 8.4):
  - New `tests/import-e2e.sh`: 30/30. Covers the form; an .ics imported for a member (author, submitter email, group, host, date/place/link, their email, the group subscriber's "New event" email with date and place, My Events, the group page); a CSV for an email with no account (Outlook columns, prices, all-day, a two-line description, guest ownership, the summary listing skipped rows and price notes, the owner's email, Manage My Submission finding them); re-upload without duplicates; an unknown username, an unknown group, a wrong file type and a CSV without Title/Start are refused; a non-manager can't import; the copy text (fields, link, line breaks, no HTML, host named once, Price Not Posted, CANCELLED).
  - `tests/org-e2e.sh` 147/147 and `tests/calendar-e2e.sh` 73/73 still pass. No plugin warnings in `debug.log`. `php -l` on every changed PHP file.
  - Mac setup as before (local router script, port 8898, uncommitted copies of the scripts).
- **Not possible:** importing straight from Facebook or FetLife. Facebook offers no export of a group's or Page's events without an approved Facebook app, and FetLife has no export or API (and automated collection breaks its rules).

---

## 1.44.1

**Page-edit emails showed "Array" for extra titles** (owner, 2026-10-13: "fix the Array email bug").

- When a titleholder with more than one title saved "Edit this page", the email to the site admin listed each extra title as "Array", and PHP logged "Array to string conversion" (`class-cec-org-editor.php`, the change list). The "More titles" rows (1.42.0) are arrays of title / year / producer; the email now shows each as its title line, e.g. "Mr. Ohio Pup 2025 · Produced by Ohio Pups", the same wording as the page and card.
- **Verification** (local WordPress test kit, macOS, PHP 8.4):
  - `tests/org-e2e.sh` 147/147. New check: the change email lists the extra titles by name and never says "Array". The same check fails on 1.44.0 (146/147), so it catches the bug.
  - No plugin warnings in `debug.log` (1.44.0 logged this one 6 times per run).
  - `php -l` on the changed file.
  - Same Mac setup as 1.44.0 (local router script, port 8898, not committed).

---

## 1.44.0

**Homepage grids: 6 random cards and a "See More" button** (owner, 2026-10-13: "setup the sections on the homepage for Organizations and Titleholders to show 6 and rotate randomly and have a 'see more' option that would go to the regular page for each"). Also brings the 2026-10-12 live-only changes (1.43.0) into the repository.

- **`[cec_partner_orgs]` gets four options:** `limit="6"` shows that many cards; `shuffle="yes"` picks a different random set on every visit; `more="/organizations/"` adds a **See More** button under the grid; `more_label="…"` changes its text (default "See More"). Grids without them are unchanged.
  - The shuffle runs in the visitor's browser. colandb.com's homepage is cached at the CDN for up to a week, so a server-side shuffle alone would show everyone the same cards until the cache is cleared. The server order is shuffled too, for uncached pages.
  - Every listed card is still in the page; cards past the limit start `hidden`, so without JavaScript the first 6 show.
  - `limit` is ignored with `filter="yes"`, which needs every card.
  - The button is an outlined pink button, so it doesn't look like the solid "Submit an Organization or Titleholder" button below it. Screen readers hear "See More organizations" / "See More titleholders".
- **Homepage:** after updating, change the two homepage shortcode widgets to `[cec_partner_orgs kind="organization" limit="6" shuffle="yes" more="/organizations/"]` and `[cec_partner_orgs kind="titleholder" limit="6" shuffle="yes" more="/titleholders/"]`, and at the same time unpublish the Angie snippet **COL&B Homepage Grid Rotation** (id 942), which did this on live in the meantime. Running both would hide cards twice.
- **1.43.0, applied on live on 2026-10-12 outside the repository, now imported** (byte-identical to the live files apart from the live-only `-loc1` stylesheet cache buster, which this version bump replaces):
  - Structured location for organizations and titleholders: City (required) + State (required) + ZIP (optional, private, never shown) in the submission form, review screen, "Edit this page" and wp-admin. New term meta `cec_loc_city`, `cec_loc_state`, `cec_loc_zip`; `cec_region` stays as the display text ("Columbus, OH").
  - `filter="yes"` filters by state, then city once a state has 2+ cities; "Location not listed" for listings without one.
  - The grid filter finds its grid again if it wasn't found when the page loaded.
  - `tests/org-e2e.sh` updated for it: submissions, approvals and page edits send a city and state; the filter checks look for "Filter by state" and state codes.
- **Verification** (local WordPress test kit, macOS, PHP 8.4):
  - `tests/org-e2e.sh` 146/146. New checks: `limit` hides all but N cards and keeps them all in the page; `shuffle="yes"` adds the in-browser shuffle; `more` adds the button with its screen-reader text; `more_label`; titleholder wording; `limit` ignored with `filter="yes"`; grids without the new options unchanged.
  - Headless Chrome on the test site: 11 listed organizations, `limit="6" shuffle="yes"`: 6 visible on each of 5 loads, 5 different sets, See More shown and linking to `/organizations/`.
  - The same browser-side shuffle has been running on colandb.com since 2026-10-13 (the snippet above); checked there at desktop and phone widths.
  - `php -l` on every changed PHP file.
  - Mac notes: PHP 8.4's built-in server needed a small router script for pretty permalinks, and port 8899 was held by an old test server, so the run used a local copy of the script on port 8898. Not committed.
  - Not covered: an existing "Array to string conversion" warning in the page editor's change email for titleholders with extra titles (`class-cec-org-editor.php`, from 1.42.0) is unrelated and left for a separate fix.

---

## 1.42.0

**Titleholders with more than one title; the city/region filter shows sooner** (owner, 2026-10-11: "You should also be able to filter titleholders by location", "some titleholders have multiple titles").

- **More titles** (`cec_titles_more`: rows of title / year / producer, up to 7 beyond the first). The first title stays in the existing title/year/producer fields, so every listing keeps its current title.
  - **Edit this page:** a "Titles" section shows the first title plus a row for each extra title, with two empty rows to add more. Clearing a title removes it.
  - **Submission form:** two optional "more titles" rows. The review screen shows and edits them, and approving saves them.
  - **Page and cards:** each title line shows ("Great Lakes Handler 2026 · Produced by …", then the next).
  - A year that isn't four digits is dropped from that title only, with a note.
- **The city/region filter** (`filter="yes"`) now shows as soon as any listing has an area, plus "Area not listed" for listings without one. Before, it needed two different areas, so the Titleholders page never showed it.
- The filter dropdown keeps its natural width (the theme stretched selects to 100%).
- **Verification** (local WordPress 7.1.2):
  - `tests/org-e2e.sh` 140/140. New checks: one area plus listings without one shows the filter with "Area not listed"; titles 2–3 show on the page and the card, in order; a bad year is dropped from that title only; extra titles from a submission survive review and approval.
  - `php -l` on every changed file.

---

## 1.41.1

**Dark text on the calendar's pink elements** (owner, 2026-10-11: "make sure all the text on the website is the correct color").

- A contrast check of every public page found white text on the secondary pink (#FF50D7) at 2.85:1, under the 4.5:1 minimum. It affected multi-day event bars, the Today button, the selected day number and the "paid" price badge.
- Those now use #100F0F (7.4:1), like every other pink button on the site. Only colours change in `assets/css/frontend.css`; no markup changes, so the month view's HTML is unchanged.
- The same check found theme-level problems (#333 page text and #CC3366 links from the Hello theme, the active Elementor tab). Those were fixed in the site's Additional CSS, not in this plugin.

---

## 1.41.0

**City/region filter on the listing pages, space above the footer, buttons that keep their colours anywhere** (owner, 2026-10-11: "can you create a space between the footer and content as well as a filter to filter profiles by city or region?").

- **City or region** (`cec_region`) for every listing. It's set on the submission form, in the review screen, in "Edit this page" and on the group's admin screen. A list suggests areas already in use, so spellings match.
  - Shown in small capitals on each card.
- **`[cec_partner_orgs filter="yes"]`** adds "Filter by city or region" above the cards when listings use two or more areas.
  - "Columbus", "columbus " and "COLUMBUS" count as one area.
  - The list shows "N shown" and "Nothing listed in that area yet." when empty.
  - Without JavaScript the filter stays hidden and every card shows. The homepage grids keep no filter.
- **Space above the footer:** 5rem below the cards and at the end of every `/partner/` page.
- **`.cec-org-btn` defines its own colours**, so a button placed on an ordinary page (like the Submit buttons) is pink without a wrapper.
- **Verification** (local WordPress 7.1.2):
  - `tests/org-e2e.sh` 134/134, with new checks: region saved from a submission; the filter shows each area once; cards carry and show their area; no filter without `filter="yes"`.
  - `php -l` on every changed file.

---

## 1.40.0

**A shortcut to the page's events, and the gallery grouped by photo shape** (owner, 2026-10-10: "Add a shortcut at the top to my events of the template and organize the photos by format because it looks messy").

- **"See my events ↓"** (organizations: "See our events ↓") in the top section of every `/partner/` page. It jumps to Upcoming Events (`#cec-org-events`), scrolling smoothly unless the visitor has asked for reduced motion.
- **The gallery groups photos by shape:**
  - landscape: 4:3 tiles, about 3 across;
  - portrait: 3:4 tiles, about 4 across, framed toward the top so faces stay in view;
  - square: 1:1 tiles.
  - Each group is an even grid, so rows line up; order within a group follows the gallery order.
  - Phone photos are 4:3 or 3:4, so they aren't cropped. Wider or taller photos are trimmed slightly at the edges, and the full photo opens on click.
- **Verification** (local WordPress 7.1.2):
  - `tests/org-e2e.sh` 130/130, with 2 new checks (grouping, the shortcut).
  - In Chromium, a gallery of 3 landscape, 3 portrait and 1 square photo showed three even groups. The shortcut scrolled to Upcoming Events.
  - `php -l` on every changed file.

---

## 1.39.1

**The submission form is easier to reach and quicker to fill in** (owner, 2026-10-10: "how will new members/titleholders submit their information? It needs to be available to them to submit").

- `[cec_submit_org]` opens on **Titleholder** when linked with `?kind=titleholder`; the Titleholders page's "Submit your title" button uses this.
- **Signed-in visitors** get their name, email and member username filled in, so an approved listing links to their account. Signed-out visitors see an empty form.
- **Gallery photos are no longer cropped** (owner: "The crop of these photos is weird"). Every photo was forced into a 4:3 landscape box, cutting heads and feet off portrait phone photos. Each photo now shows at its own shape, left to right in gallery order: 3 columns on wide screens, then 2, then 1.
- **On the site, outside the code:** links to the form were added in the footer's Resources menu, on the Organizations and Titleholders pages, and as a homepage button under the listings.
- **Verification** (local WordPress 7.1.2): `tests/org-e2e.sh` 128/128, with new checks for `?kind=titleholder`, no prefill when signed out, and prefill when signed in. `php -l`.

---

## 1.39.0

**Menu dropdowns for organizations and titleholders; a titleholder's events on their page** (owner, 2026-10-10: "In the header menu there should be a place for MEMBER & AFFILIATED ORGANIZATIONS and TITLEHOLDERS"; "Any events that I'm attending that are publicly available via my calendar as a member should show here").

- **Automatic menu dropdowns.** A menu item with the CSS class `cec-partner-orgs-organization` (or `cec-partner-orgs-titleholder`) gets every listed organization (or titleholder) as its dropdown, in display order, linking to each `/partner/` page. Newly approved or unlisted groups appear or disappear by themselves.
- **"Upcoming Events" on a group's page can include more events.** New filter `cec_partner_org_event_ids`. The extra events are merged with the group's own, upcoming only, sorted by date, in the same cards. Member Planning 0.23.0 uses it for the events a titleholder is going to.
- **Verification** (local WordPress 7.1.2):
  - `tests/org-e2e.sh` 124/124. New checks: the dropdowns list the right groups and links, and an unlisted group drops out by itself. Titleholder events: Public ones for everyone, All members ones for signed-in members, never private or past ones, hidden from someone blocked, other groups unchanged.
  - `calendar-e2e.sh` 73/73. `php -l` on every changed file.

---

## 1.38.0

**Photo shape and cropping, tidier tags, "Message me on Telegram", "Ask for my …"** (owner, 2026-10-10, from a screenshot of the Foxxy Force page).

- **Photo shape:** Circle or Rectangle (portrait, 4:5), chosen in the editor (`cec_photo_shape`). Used on the page, the editor thumbnail and the homepage card. A rectangle gets a lime frame.
- **Cropping in the browser:**
  - After choosing a photo, or clicking **Adjust crop** on the current one, a crop box opens. Drag to move; zoom with the slider, the scroll wheel or the + and − keys; the arrow keys also move it.
  - The bright area matches the chosen shape. **Use this crop** replaces the chosen file with the cropped JPEG (1000×1000, or 960×1200 for a rectangle), saved with **Save changes**.
- **Tags (bullet points) on the page are a grid:** two even columns, an odd last tag centred, one column on phones.
- **Titleholder buttons speak for one person:** "Message me on Telegram" and "Visit my website". Organizations keep "Join our Telegram".
- **"Ask for my <network>"** checkbox under each link except Website and Other. When ticked:
  - the link is neither saved nor shown;
  - the page shows a dashed tag, "Ask for my FetLife" (organizations: "Ask for our …").
  - Stored as `cec_social_ask`; included in history, Restore and the admin email.
- **Verification** (local WordPress 7.1.2):
  - `tests/org-e2e.sh` 115/115, with new checks: Message me on Telegram, Ask for my FetLife with no link stored or shown, rectangle shape saved, tag grid, organizations keep Join our Telegram.
  - In Chromium on the local site: chose Rectangle, picked a 1600×1000 photo, dragged and zoomed, used the crop and saved. The page photo became 960×1200 and the shape was saved. Desktop and phone screenshots of the page checked.
  - `calendar-e2e.sh` 73/73. `php -l` on every changed file.

---

## 1.37.1

**Add any number of photos, remove any before saving, and a refresh no longer wipes your work** (owner, 2026-10-10: "I added 17 photos and it says i can only upload 15 but does not give me the option to deselect any", "when i refresh the page everything wipes clear", "This is the same for the text entry fields not just the photos").

- **Photos upload one at a time as soon as they're picked.** There's no per-save limit any more; the gallery still holds 60.
  - Each photo appears under **New photos** with a thumbnail, a caption box and a **Remove** button, and shows its progress.
  - A photo that's too large or isn't an image is marked on its own row with the reason, and the others carry on.
  - New endpoint `admin-post.php?action=cec_org_upload`, one photo per request, with the editor's own nonce. The old one-request upload stays as the no-JavaScript fallback.
- **Uploaded photos survive a refresh**: they're stored on the server, not on the page, until you save with the consent box ticked.
- **Everything typed is kept as a draft in your browser:** name, card text, bullet points, bio, mission, title, links, captions and photo removals.
  - After a refresh it's brought back with a note ("…They aren't live until you save.") and a **Discard them** button.
  - Saving clears the draft. Drafts older than 14 days are ignored.
  - Leaving or refreshing with unsaved changes asks first.
- **Verification** (local WordPress 7.1.2):
  - `tests/org-e2e.sh` 106/106, with 5 new checks for the upload endpoint: a photo is stored and kept off the page; a non-image gets a clear error; non-editors, a bad nonce and signed-out requests are refused.
  - In Chromium on the local site:
    - Typed bio, card text and an Instagram link survived a refresh, with the notice shown.
    - 17 photos uploaded one by one ("All photos uploaded…"). After removing 2 and typing a caption, a second refresh kept 15 photos and the caption.
    - Saving with the box ticked put exactly those 15 in the gallery with the caption, deleted the 2 removed photos and cleared the draft.
  - `calendar-e2e.sh` 73/73. `php -l` on every changed file.

---

## 1.37.0

**The page editor never throws work away, and takes photos in bulk** (owner, 2026-10-10: "because I didn't enter a name it wiped out all my work for editing my profile and that's a problem. I should also be able to upload photos in bulk").

- **What went wrong.** A save with any problem (an empty name, a bad link, a missing consent tick, one bad photo) was rejected as a whole. The text came back, but every photo picked had to be chosen again, and gallery caption and order changes were lost.
- **Now every save keeps everything that's valid:**
  - Anything that can't be used keeps its current value: an empty or duplicate name, an empty bio, a bad year, a link that can't work.
  - The editor then lists exactly what wasn't changed. A bad link is shown as typed, and a bad photo is named.
- **Photos without the consent box are kept, not dropped.** They stay in the editor under "Uploaded, not on your page yet", with caption boxes and a Delete option. They are not on the page. Ticking the box and saving adds them to the gallery.
- **Bulk upload:** one "Add photos" field takes many photos at once, up to 15 per save. New photos go at the end of the gallery, and captions and order are set afterwards.
  - Up to 10 MB per photo (was 5 MB, for phone photos), and the gallery now holds 60.
  - Before sending, the browser checks the count, each photo's size and the total (90 MB, under the CDN's 100 MB limit). A too-large upload is stopped with a message, so the form is never lost.
- An edit that changes nothing no longer adds a version or emails the admin.
- **Verification** (local WordPress 7.1.2):
  - `tests/org-e2e.sh` 101/101. The editor checks were rewritten for keep-what's-valid: a bad link and a bad photo don't block the rest; the previous link is kept; notes list the typed link and the photo name, once; photos without consent are held, shown with caption boxes, not public; confirming adds them with their caption; many photos at once.
  - In Chromium on the local site, choosing 16 photos is stopped with "Please choose up to 15…" and the form stays; choosing 3 shows "3 photo(s) ready to add."
  - `calendar-e2e.sh` 73/73. `php -l` on every changed file.

---

## 1.36.0

**Titleholders and organizers manage their own homepage card** (owner, 2026-10-10: "I need the titleholders to be able to manage these cards through their logins. Not to be managed by the site admin except for approval").

- **"Your homepage card" at the top of "Edit this page":**
  - **Name.** Renaming keeps the page address. A name another group already uses is refused.
  - **Card text** (optional, up to 200 characters). Shown on the card instead of the start of the bio.
  - **Bullet points**, now for titleholders too (up to 8).
  - Together with the photo and title line already in the editor, everything on the card is theirs to change. The site admin keeps approval of new listings, kind, listing on/off and the private contact.
- **Cards update for everyone right away.** After an editor save, a Restore, an approval or a save on the group's admin screen, the pages that show `[cec_partner_orgs]` (the homepage) are re-saved and Elementor's cache is cleared, so the host's CDN stops serving the old cards. New action `cec_partner_orgs_changed` for other caches.
- History, Restore and the admin email now include name, card text and bullet points.
- **Verification** (local WordPress 7.1.2):
  - `tests/org-e2e.sh` 96/96, with 6 new checks: name, card text and bullets on the grid; page address unchanged; grid page re-saved; a duplicate name and an empty name refused; a titleholder's own card text and bullets; Restore brings back the name.
  - `calendar-e2e.sh` 73/73. `php -l` on every changed file. The month view is untouched.

---

## 1.35.0

**Titleholders and organizers edit their own page, with an event gallery** (owner, 2026-10-10: "I also need a way as the titleholder to update that page including text, info, external links, and photos. There should also be an option for gallery uploads so I can showcase events I've been to and add captions". The owner chose: edits go live right away, the gallery is public).

- **"Edit this page"** on `/partner/<slug>/` for anyone allowed to edit it: site admins, plus members the member plugin allows. Member Planning 0.21.0 allows members linked as Titleholder or Organizer. The new filter `cec_partner_org_can_edit` decides. The editor is at `?cec_org_edit=1` and covers:
  - bio or description, highlights (organizations), mission / areas of focus;
  - title, year and producer (titleholders);
  - every link (the same checks as the submission form; the first link is the big button);
  - the photo or logo: replace or remove.
  - The name, kind, listing and private contact stay with the site admin.
- **Gallery ("Events & Appearances" for titleholders, "Gallery" for organizations):**
  - Up to 30 photos with captions, shown publicly below the mission, each linking to the full-size image.
  - Add up to 6 at a time (JPEG/PNG/WebP, 5 MB each, checked by content); change captions and order; remove photos.
  - Adding photos requires ticking "Everyone who can be recognised… agreed to be shown publicly".
- **Live right away, with undo:**
  - The site admin is emailed each change by a titleholder or organizer, with before/after text and a link.
  - The last 10 versions are kept. The group's edit screen in wp-admin lists them under **Page edits** with a **Restore** button.
  - Photos no kept version uses any more are deleted from the media library. Deleting a group deletes its gallery.
- Signed-in views of group pages, and the editor, are sent no-cache headers.
- **Verification** (local WordPress 7.1.2):
  - `tests/org-e2e.sh` 90/90, with 28 new checks covering who sees the button; refusal for non-editors, a bad nonce and after a role downgrade; editor fields (no name or contact); no-cache; bad link kept and reported with nothing saved; consent required; save live with gallery captions and order; admin email; history; public gallery markup; caption, order, remove and photo replace; Restore; pruning; admin edits not emailed.
  - `calendar-e2e.sh` 73/73, `profile-e2e.sh` 84/84, `account-e2e.sh` 69/69.
  - `e2e.sh` 60/60 when run on its own. Run straight after the other suites, it failed 2 email-verification checks once and then passed on rerun. Those checks don't touch this code.
  - `php -l` on every changed file. The month view is untouched.

---

## 1.34.0

**Organization & titleholder listings people can submit, one page template for every group, and a homepage grid** (owner, 2026-10-10: "a page and form … that will allow people to submit an affiliate organization", "You approve first", "Anyone, with a contact email", "One template at /partner/name/ (old pages redirect)", and titleholders get "photo, year, title, producer, bio, areas of focus/mission, and social links").

- **`[cec_submit_org]`, the public form.** Anyone can send an organization or a titleholder:
  - name, logo or photo (JPEG/PNG/WebP up to 5 MB, checked by content and renamed), short description or bio, highlights (organizations), mission or areas of focus;
  - titleholders also give title, year and producer;
  - links: Telegram, website, Facebook, Instagram, FetLife, X, Bluesky, other. Each is checked against its network's addresses; a Telegram `t.me/c/…` message link is refused with a note asking for the group's invite link (`t.me/+…`), because `/c/` links only open for people already in the group;
  - a **private contact** (name, email, optional phone), never shown on the site;
  - optionally a **member username or email** to link to the listing.
  - Errors send you back with your answers kept. A hidden honeypot field and a limit of 5 submissions per address per day stop bots. Signed-out visitors can use it (no nonce, so cached pages still work).
- **Nothing is public until approved.** Submissions go to **Events → Org Submissions** as pending, and the site admin is emailed a review link; the contact gets an acknowledgment. The review screen lets you correct anything, then **Approve and publish** or **Decline** (the contact is emailed either way). Approving:
  - creates the calendar group (or fills in an existing one with the same name, so there's never a duplicate), lists it on the grid, sets its logo and website;
  - emails the contact the page link (only the first time);
  - fires `cec_partner_org_member_requested` for the named member, which the member plugin (0.20.0) uses to link their profile.
- **Every group's page is `/partner/<slug>/`** (the existing calendar group page, now with a full header): logo or photo in a circle, name, the titleholder's title line ("Great Lakes Handler 2026 · Produced by …"), description, highlights, link buttons (Telegram first, as "Join our Telegram", then "Visit Website" and the rest), a Mission / Areas of Focus card, then Upcoming Events with subscribe links. Styled like the homepage (Montserrat 900 pink headings, lime rule, pink square buttons that turn lime). Filter `cec_partner_org_page_extra` lets the member plugin add its section.
- **Old hand-built pages redirect.** An address like `/ohio-petplay-alliance/` that no longer finds a page sends a 301 to `/partner/ohio-petplay-alliance/`, so links already shared keep working once those pages are unpublished.
- **`[cec_partner_orgs]`, the homepage grid:** listed groups in the order set on each group, with image, name, title line, highlights (or the description) and a Learn More button to the group's page. `kind="organization"` or `kind="titleholder"` shows just one kind; the default is both.
- **Admin: Events → Partners & Titleholders** edit screen gains Kind, Listed on the site + order, highlights, mission, title/year/producer, every link, and the private contact (read-only). The list shows Kind and Listed columns.
- **Privacy:** a submission contact's export includes their submissions; erase removes their contact details from the submission and the group (the group itself stays).
- **Verification** (local WordPress 7.1.2):
  - New `tests/org-e2e.sh`: 60/60, covering the form (validation and kept answers, honeypot, image check, rate limit, Telegram invite link, titleholder fields, year), review (non-admin refused, approve, approving again without new email, existing group filled in, decline), the page (contact never shown, Telegram first, titleholder title line), the grid (listed only), old-address 301 and real 404, member links, export/erase, no PHP warnings.
  - `calendar-e2e.sh` 73/73, `e2e.sh` 60/60, `account-e2e.sh` 69/69, `messages-e2e.sh` 51/51, `directory-e2e.sh` 21/21. `follows-e2e.sh` fails the same 3 checks on unchanged `main`, so that is pre-existing.
  - `tests/snap.php` month view before/after: identical (12/12). `php -l` on every changed file.

---

## 1.33.0

**"Next event" links for a Partner Organization or Titleholder** (owner, 2026-10-08: the homepage's event cards "should go to the most recent event for that group").

- **`/wp-admin/admin-post.php?action=cec_next_event&org=<slug>`** sends the visitor to that group's next published event. An event in progress counts as next. Cancelled and unpublished events are skipped.
  - With nothing scheduled, the link goes to the group's most recent event.
  - With no events at all, it goes to the group's calendar page (`/partner/<slug>/`).
  - An unknown group goes to the home page.
- **Never goes stale:** served from `admin-post.php` (like the `.ics` files since 1.32.1) because the host's CDN caches ordinary public pages for signed-out visitors for days, which would freeze the link on an old event. The redirect is also sent `no-store` and `noindex`.
- **For page builders and themes:** `cec_next_event_url( $slug )` returns the link.
- **Verification** (local WordPress 7.1.2): `calendar-e2e.sh` 73/73, with 10 new checks. They cover the helper's link; the next event chosen over a cancelled one; no-store/noindex headers; signed in and signed out; an event in progress counting until it ends; unpublished events skipped; falling back to the latest event, then to the group's page; and an unknown group. `php -l` on the changed files.

---

## 1.32.2

**"Partner Organizations" is now "Partner Organizations & Titleholders"** (owner, 2026-10-08), because the list also holds individual titleholders (for example Foxxy Force, Great Lakes Handler 2026).

- Renamed everywhere it's shown: the event's sidebar box and admin menu (Events → **Partners & Titleholders**), its add/edit/search screens, the Calendar Admin dashboard tab, the event page heading, the submit, guest-edit and My Events forms ("Don't see your organization or titleholder? Add it"), the subscribe form ("Or just specific organizations or titleholders") and the settings-page help text.
- **Nothing else changes:** the taxonomy (`cec_partner_org`), its stored data and its web addresses (`/partner/<name>/`) are the same, so no links break. "Host Organization" fields are left as they are.
- **Verification** (local WordPress 7.1.2): `php -l` on every changed file; the `tests/snap.php` month-view comparison before/after is identical (12/12); `calendar-e2e.sh` 63/63; new labels confirmed on the taxonomy, the submit form (with an organization present) and the subscribe form.

---

## 1.32.1

**Public calendar feeds no longer cached for a week; tapping anywhere in a day opens it** (owner, 2026-10-05: "fix the public feed caching too", and "it forces me to click the number instead of the box of the day … that is counter intuitive").

- **.ics files moved out of the host's CDN cache.** On the live site the CDN served stored copies of `?cec_ical=all` (`ec-cdn-status: hit`, `s-maxage=604800`), so subscribers could see new or changed events up to a week late.
  - The site feed and single-event downloads are now served from `wp-admin/admin-post.php?action=cec_ical&feed=all` and `&event=<id>`, which the CDN excludes.
  - The Subscribe (iCal) and Download .ics buttons use the new addresses.
  - The old addresses redirect permanently (301), so existing subscriptions follow automatically.
- **Calendar: the whole day box opens the day**, not just the number. Events in a box still open the event, and the number is still the keyboard path. Hovering anywhere in a day lights its box.
- **Fixed: selecting a day lit up every day.** The selected-day check looked for the number inside the box, but the number is a separate layer, so jQuery toggled every box instead of one. Boxes now carry their own date.
- **Verification:**
  - `calendar-e2e.sh` 63/63, with 6 new checks: the feed and an event's .ics at the new address, the old addresses redirecting (301), unknown events not found, event pages linking the new address, and day boxes carrying their date.
  - `e2e.sh` 60/60.
  - In a browser on the local test site: clicking empty space in a day opens its events with only that day highlighted, and clicking an event still opens it.

---

## 1.32.0

**Calendar files for subscribed calendars** (for Community Member Planning 0.18.0's private calendar feed).

- **New public `CEC_Ical::calendar( $events, $name, $tentative_ids )`:** builds an .ics for any list of events with the same code as the site feed and single-event downloads, so times, time zones, all-day events, locations and cancelled/postponed statuses come out the same.
  - Events listed in `$tentative_ids` are marked TENTATIVE (a member who's only "Interested").
  - The file asks calendar apps to refresh every 4 hours (`REFRESH-INTERVAL`, `X-PUBLISHED-TTL`).
- **Nothing changes** for the existing site feed or .ics downloads.
- **Verification:** `calendar-e2e.sh` 56/56 (the private feed checks use it); `e2e.sh` passes.

---

## 1.31.1

**Signed-in quick links trimmed** (owner, 2026-10-05, screenshot of Community Events: "This all seems very redundant"). The 1.31.0 bar repeated things already on the page or in the site's account menu:
- "Signed in as" and Sign out (already in the "Hello" menu);
- Member area (in the top menu and the "Hello" menu);
- Calendar dashboard (in the "Hello" menu as Calendar Admin);
- Submit an event (the page's own Submit Event tab).

It now shows only links the page doesn't already offer: **My calendar**, from Community Member Planning 0.17.3, and My submitted events where a `[cec_my_events]` page exists. Nothing to show means nothing is shown. The `note` option for signed-out visitors is unchanged.

- **Verification:** `calendar-e2e.sh` 45/45; `e2e.sh` 60/60. Checked in a browser on the local test site.

---

## 1.31.0

**Quick links when you're signed in** (owner, 2026-10-05: should there be a "my events" quick link for personal calendar management on the Community Events page?). The login box used to say only "You're already logged in."

- **Signed in, `[cec_login]` and `[cec_register]` now show "Signed in as <name>"** with links as buttons:
  - Calendar dashboard (event managers);
  - My submitted events (when a page has `[cec_my_events]`);
  - Submit an event;
  - Sign out, which returns to the same page.
- **Other plugins add theirs through the new `cec_account_links` filter** (key => label, URL). Community Member Planning 0.17.2 puts My calendar and Member area first. The first link is the main button.
- **New `note` option on `[cec_login]`**, e.g. `[cec_login note="Log in or register to keep track of your events and RSVPs."]`. The note shows above the form only to signed-out visitors, so a page no longer needs a separate text block that signed-in members see too.
- **Verification:** `calendar-e2e.sh` 44/44, with 4 new checks for the signed-out note, the signed-in links in both boxes, and accounts that haven't finished setting up. `e2e.sh` 60/60. Checked in a browser on the local test site, signed in and out.

---

## 1.30.0

**Room for "Add to my calendar" on event pages** (owner, 2026-10-05: no way to "Add to my calendar" while signed in). Small additions for Community Member Planning 0.17.0; nothing changes for visitors without it.

- **New hook `cec_single_event_calendar_actions`** on the single event page, under "Add to Google Calendar / Download .ics". It receives the event data. The member plugin puts its "Add to my calendar" box there.
- **New `CEC_RSVP` functions for a signed-in member's RSVP:**
  - `accepts_member_rsvp()`: the event takes RSVPs here, is published and is scheduled;
  - `has_member_rsvp()`;
  - `add_member_rsvp()`: same capacity lock and limit as the form, no guests, name and email from the account; returns `ok` / `exists` / `full` / `closed`;
  - `remove_member_rsvp()`.
  - When a member marks Going, the RSVP count stays right. Interested or Remove takes the RSVP away.
- **Already on the list:** a signed-in member who has RSVP'd sees "You're on the list for this event." instead of the RSVP form again, so they can't be counted twice.
- **Verification:** `calendar-e2e.sh` 39/39 (with Community Member Planning 0.17.0); `e2e.sh` passes.

---

## 1.29.0

**Automatic data clean-up** (owner, 2026-10-05: "Yes" to building it, so the site does what the privacy statement says). New `CEC_Retention` runs once a day (WP-Cron `cec_daily_retention`, scheduled on activation and on upgrade, cleared on deactivation):

- **RSVPs and waitlist entries** are deleted 12 months after their event ends.
- **The submitter's email and private edit link** are removed from events 12 months after they end. The events themselves stay published.
- **Volunteer sign-ups** are deleted 2 years after they were sent.
- **The event change log** keeps 2 years.
- Periods can be changed with the `cec_retention_periods` filter (days). The last run's counts are stored in the `cec_retention_last` option.
- Verification: new `tests/retention-e2e.sh` 17/17 (shared with Community Member Planning 0.15.0); `e2e.sh` 60/60.

---

## 1.28.1

**Signing in with no destination no longer always lands on Submit an Event** (owner report: after signing in it "went to the submit an event page again and not the member profile").

- The `[cec_login]` form no longer fills in Submit an Event as its destination when the page wasn't given a `redirect_to`; the destination is chosen after sign-in, per account, by the new `CEC_Auth::default_redirect( $user )`: event managers → the dashboard, everyone else → Submit an Event, as before.
- New filter `cec_login_default_redirect( $url, $user )` so another plugin can change that default. `wp-login.php` sign-ins (`login_redirect`, `CEC_Roles`) use the same default. A destination that was asked for (`redirect_to`) is still respected.
- Verification: `account-e2e.sh` 69/69 (new: wp-login and the site form with no destination, an explicit destination, event managers), `e2e.sh` 60/60, `dob-e2e.sh` 34/34.

---

## 1.28.0

**Hooks for "people you follow"** (with Community Member Planning 0.12.0, owner 2026-10-05).

- New filter `cec_event_social_label( $label, $event_id )`: a short label for the current viewer (e.g. "2 people you follow are going"). Empty by default, so the calendar looks exactly as before without Community Member Planning.
- When a label is set: a small pink dot on the event's pill or bar in the month grid (the label is in its tooltip and read by screen readers), and a line under the event on the phone day list (server-rendered and JavaScript-rendered).
- New action `cec_rsvp_created( $event_id, $user_id )` after an RSVP is saved (`$user_id` is 0 for guests).
- Verification: `e2e.sh` 60/60 and `follows-e2e.sh` 27/27 on local WordPress 7.1.2; the dot and phone line checked in a browser at 1280 px and 375 px.

---

## 1.27.2

**New filter `cec_register_redirect`** ( `$redirect`, `$user_id` ): where a brand-new account goes after `[cec_register]`. The default is unchanged (the form's redirect, usually Submit an Event); the member plugin uses it to send new members to their member area (owner report 2026-10-04: after registering on the live site they landed on Submit an Event instead of the member profile).
- Verified in a local WordPress 7.1.2 by `tests/dob-e2e.sh`. `php -l` clean.

## 1.27.1

**Sign-up extension hooks** for the member plugin's required date of birth (Community Member Planning 0.4.0). `[cec_register]` gains:
- `do_action( 'cec_register_form_fields' )` inside the form, before the honeypot;
- `apply_filters( 'cec_register_validate', true )` after the existing checks and before the account is created: a `WP_Error` refuses the sign-up with its code as `cec_register_error`;
- `apply_filters( 'cec_register_error_messages', $errors )` for those codes' messages;
- `do_action( 'cec_user_registered', $user_id )` once the account exists.

This plugin stores nothing those hooks collect (the events/member data boundary in `CLAUDE.md`). With the member plugin inactive the form is unchanged.
- **Verified** in a local WordPress 7.1.2 with `tests/dob-e2e.sh`: a missing date or an under-18 date refuses the sign-up and creates no account; a valid date creates it; no birth data is stored under this plugin's keys. `php -l` clean.

## 1.27.0

**Phone month grid replaces the long phone agenda** (owner request: the phone calendar "goes to a list view and is inconvenient to scroll through"). Below 700px wide, `[cec_calendar]` used to show every day of the month with every event running that day, about 84 entries and roughly 22 phone screens for October 2026, because each national weekend repeats on every day it runs. It now shows a compact month grid on one screen, and tapping a day lists that day's events underneath. The design was approved from a mockup built with the real October 2026 events.
- **Grid** (`CEC_Month_Grid::render_phone()`): day buttons with up to 3 dots for single-day items (`PHONE_MAX_DOTS`), thin bars for multi-day items drawn across the days they run (at most `PHONE_MAX_LANES` = 2 per week row, same greedy lane packing as the desktop grid), and "+N" for the rest. Weekday labels follow the First Day of Week setting. Today is ringed; the selected day is filled.
- **Tapped-day list** (`render_phone_day_list()`, mirrored in `frontend.js` `selectPhoneDate()`/`phoneCard()`): heading, event count, then what **starts that day** and what's **still running** ("day 9 of 12"), so a one-night event isn't buried under a 12-day festival. Each event is one full-width tappable card (title, time or date range, place and price). It opens on today, or on the first day with events when viewing another month. The server renders the initial list, so it shows before JavaScript loads. Tapping a day also updates the desktop click-a-date panel, so the two stay in sync.
- **Additive payload fields** in `.cec-cal-data`: `id`, `endDate` (true end date), `time` (start time with timezone, single-day timed events only) and `status`. Grid items gain `detail['time']`; items from other callers without it fall back to "All day" / the date range.
- **Theme-proofed from the start:** every day button and card is scoped under `.cec-calendar-wrap` with `!important` on its visual properties. Hello Elementor's `reset.css` restyles every `button` (pink 1px border, `#cc3366` text, 8px 16px padding), and without this it repainted the day cells. That was confirmed on a copy of the live page before the fix.
- Removed: the `.cec-cal-agenda` markup and CSS (only used by this view; nothing else in the repository referenced it). Desktop (700px and wider) is unchanged. `tests/snap.php` output will differ in the phone section and the payload, intentionally.
- **Verification:** a test page made from the live colandb.com Community Events page (real theme CSS and real October 2026 events), with the phone section generated by a Python copy of `render_phone()` and the new `frontend.css`/`frontend.js`. At 375px: the desktop grid is hidden and the phone grid shown; day cells keep their own styling against the theme; weekday labels line up with the day columns; dots never overlap bars; no sideways scrolling; tapping Oct 9 lists 4 weekends starting plus Kink 101, then Maspalomas "day 9 of 12"; Oct 20 lists MAsT; an empty day shows the empty note. **Not run in a real WordPress install** (no PHP on this Mac): the PHP was reviewed by hand and bracket-checked, and CI runs `php -l`. Check the live calendar at phone width after updating.

## 1.26.3

**Three fixes from the unreleased 1.25.3 (built in another session from 1.25.2) that 1.26.2 didn't cover.** 1.26.2 already did 1.25.3's site-name and email-subject work; these are the rest, ported onto 1.26.2 by hand rather than importing 1.25.3's older base.
- **Click-a-date panel showed HTML codes.** On the live site the October panel reads "Kinks &amp;amp; Drinks &amp;#8211; Presented by Kink 101" and "MAsT:Columbus &amp;#8211; October Meeting", because `frontend.js` inserts the `.cec-cal-data` JSON with jQuery `.text()`. New `CEC_Month_Grid::plain_payload()` converts the JSON copy only (title, date range, location, host, badge) through `CEC_Event_Helper::plain_text()`. The server-rendered phone agenda above it is unchanged: it still escapes the original strings, so `tests/snap.php` output should differ only inside the `<script class="cec-cal-data">` line.
- **Subscriber "New event"/"Event update" emails and RSVP reminders showed only the start date** for a multi-day event ("When: Fri, Nov 6, 2026" for Nov 6–8). New `CEC_Event_Helper::when_text()` (`when_display` from 1.25.2 plus the timezone abbreviation) is used instead of `start_display`: "When: Fri, Nov 6 – Sun, Nov 8, 2026".
- **Duplicate detection compared the display title**, so a typed " - " became "&#8211;" and added "8211" to the words being matched, lowering the score. `find_possible_duplicates()` now uses `title_plain` (candidates already used the raw `post_title`).
- **Verification so far:** the three *bugs* were observed for real (date-panel codes on colandb.com on 2026-10-04; the start-date-only email and the lowered duplicate score on staging, with FluentSMTP Email Simulation, on 2026-10-03). The *fixes* have not yet run in any WordPress install: this Mac has no PHP, so neither `php -l` nor the `tests/` kit was run locally. Brace/bracket balance checked by script. To be verified by CI `php -l` and on staging via the pre-release before promotion.

## 1.26.2

**Fix: emails and calendar files showed HTML codes instead of characters** (spotted in the staging site's FluentSMTP log, e.g. "[Central Ohio Leather &amp;amp; Beyond] New event submitted for approval").
- `get_bloginfo( 'name' )` returns WordPress's HTML-escaped display form of the site name. New `CEC_Event_Helper::site_name()` returns it as plain text and is now used in every email subject (test email, subscription confirm, new event, event update, guest edit link, volunteer inquiry, RSVP reminder, submission notices), the `.ics` `PRODID`/`X-WR-CALNAME`, and the schema.org location/organizer fallback.
- Event titles and place names in the subscriber and RSVP-reminder emails now use the plain title (`title_plain`, from 1.25.2) and plain place name, so "MAsT:Columbus - October Meeting" no longer arrives as "&#8211;".
- **Verified in a local WordPress 7.1.2 install** with the site name "Central Ohio Leather &amp; Beyond": the new-event, event-update and RSVP-reminder emails were triggered for real and captured; subjects and bodies contain no `&amp;` or `&#…;` codes. A before/after capture of all public pages, feeds and calendars differs only in the `.ics` `PRODID`/`X-WR-CALNAME` lines (now "&" instead of "&amp;"). `php -l` clean.

## 1.26.1

**Merge: brings the other session's 1.25.2 fixes and this repository's 1.26.0 together.** 1.25.2 (multi-day end dates, midnight-to-11:59 pm events, plain-text titles in exports, duplicate price notes, filter bar layout) was built from 1.25.1 and ran only on the staging site; 1.26.0 (integration API and `CEC_Month_Grid`) was built from 1.25.1 here. Both sets of changes are kept unchanged; they touched different files apart from the version number and this file. 1.25.2 was recovered from staging with CMP Hosting Check 1.1.0 and committed as its own import first, so the history shows who changed what. A 1.25.3 is known to have existed but was never installed on either site and could not be recovered.
- `cec_get_public_event()` now also returns `title_plain` (title as entered, no HTML entities), `when_display` and `display_time_mode` from 1.25.2. Additive; `CEC_PUBLIC_API_VERSION` stays 1.
- **Verified in a local WordPress 7.1.2 install:** with 1.25.2 and then 1.26.1 installed on the same test site, 33 captured outputs (every event page, each event's `.ics` and the site-wide `.ics`, the RSS feed, `[cec_calendar]`, `[cec_events]` list and grid, `[cec_upcoming]`, and three month grids) are identical, so the merge changes nothing visitors see compared to 1.25.2. Spot-checked 1.25.2's fixes on sample events ("MAsT:Columbus - October Meeting" exports with a plain hyphen; "Fri, Nov 6 – Sun, Nov 8, 2026" on a midnight-to-11:59 pm weekend; no "12:00 am"; one "$20" per place it's shown) and 1.25.1's timezone export (America/Chicago 6–8 pm → 00:00–02:00 UTC). The Community Member Planning end-to-end suite passes 57/57 against it. `php -l` clean; zero plugin warnings.

## 1.26.0

**Feature: a read-only integration API and a reusable month-grid component, for the separate member-planning plugin (project brief Phase 2).** Approved in `docs/phase-2-integration-plan.md` (repo root). This plugin still owns public events only; nothing here reads or stores member data.
- New `cec_get_public_event( $id )` / `cec_get_public_events( $ids )` (`includes/class-cec-public-api.php`, `CEC_Public_API`). Returns an allow-listed set of public fields (title, permalink, dates, time mode, timezone, place, admission, event status, is_past, plus a ready-made month-grid item) for a **published** `cec_event` only, and `null` for drafts, pending, in-review, trashed, other post types and missing IDs. Cancelled events are still returned, with `event_status` = `cancelled`. Editorial fields (`_cec_source_url`, price-review flag) and RSVP data are deliberately not included. `CEC_PUBLIC_API_VERSION` = 1; bump it if a key is removed or changes meaning.
- New `CEC_Month_Grid` (`includes/class-cec-month-grid.php`): the month-view layout (range bars, continuation markers, "+N more", day-detail data, small-screen agenda) moved out of `CEC_Shortcodes::render_month_html()` unchanged. `render( $month, $year, $items, $options )` renders whatever items it's given and runs no query, so the member plugin can reuse it with its own permission-checked data. `render_month_html()` keeps the public query and the editor-preview splice, converts each event with `CEC_Month_Grid::item_from_event_data()`, and calls `render()`. Its signature and every caller are unchanged.
- **Verified in a real WordPress 7.1.2 install:** the public calendar's HTML was captured before and after the split for 12 cases (four months including an empty one and one with capped lanes, "+N more", cancelled and postponed bars/pills, the editor-preview highlight on a pending event, the `[cec_calendar]` shortcode, each with Sunday- and Monday-first weeks) and is **byte-for-byte identical**. The API was checked against published, pending, draft, cancelled, missing, non-event and garbage IDs (11 checks, all passing). `php -l` passes on every PHP file; zero plugin warnings in `debug.log`.

## 1.25.2

Four bugs found by testing 1.25.1 on the staging copy of the live site (WordPress 7.1.2, Hello Elementor theme, 92 real events) — the first full pass on a real install.

- **Multi-day events lost their end date on the event page.** The "When" line was start date/time plus end *time* only, so Mr. Ohio Leather Weekend (Oct 9–11) read "Fri, Oct 9, 2026 12:00 am – 11:59 pm". New `when_display` (from `CEC_Event_Helper::format_when()`) keeps the end date: "Fri, Oct 9 – Sun, Oct 11, 2026", or "Fri, Oct 9, 2026 6:00 pm – Sun, Oct 11, 2026 2:00 pm" for an event with real times.
- **Midnight-to-11:59 pm events showed "12:00 am".** About 75 imported national events are stored as exact times 00:00 → 23:59 (or 00:00 the next day). New `display_time_mode()` shows those as dates only, everywhere a time is displayed (event page, cards, list date block, preview), with no timezone label. Display only: the stored times, the saved Time Details setting and all exports are unchanged. Exposed as `data()['display_time_mode']`; forms keep using `time_mode`.
- **Titles reached calendar apps with HTML codes.** WordPress turns a typed " - " into the display code `&#8211;`, and the `.ics` `SUMMARY` used that display version, so "MAsT:Columbus - October Meeting" arrived as "MAsT:Columbus &#8211; October Meeting". New `data()['title_plain']` (the title exactly as entered) and `CEC_Event_Helper::plain_text()` are now used for the `.ics` title and description, the Google Calendar link, schema.org `name`/`description`, and the share links (WhatsApp, Telegram, SMS, X, email). On-page titles are unchanged.
- **Price showed twice ("$20 — $20").** The Phase 1a migration copied the amount out of the old price note and kept the note. The badge now leaves out a note that only repeats the amount ("$20", "20", "$20.00", "20 USD"); a note with other words ("$20 at the door") still shows. No data changed.
- **Filter dropdowns stacked one per line** on themes that set every `select` to `width: 100%` (Hello Elementor's `reset.css`). Scoped `width: auto !important` / `flex: 0 1 auto` so they sit in a row; full width below 600px. Dropdowns and the Filter button are at least 44px tall for touch.
- Verified on staging before release: the date and price-note rules were checked in a Python port against real events from the site; the filter-bar CSS was checked live against the real theme by injecting it into the staging page.

## 1.25.1

**Fix: the per-event timezone (added in 1.22.0) was ignored by everything that sends an event's time off the site** — the downloadable/subscribed `.ics` files, the "Add to Google Calendar" link, and the schema.org `startDate`/`endDate` search-engine data. All three converted the stored wall-clock time using the *site's* timezone (`get_gmt_from_date()` in `CEC_Ical::utc_ics()`, `date_i18n( 'c' )` in `CEC_Event_Helper::event_schema()`), so any event set to a timezone other than the site's landed at the wrong time in subscribers' calendars. Example, found on a real WordPress install with the site set to America/New_York: an event at 6:00–8:00 pm America/Chicago displayed correctly on its own page ("6:00 pm – 8:00 pm CST") but exported as 23:00–01:00 UTC (an hour early) and as `18:00-05:00` in schema.org. The error grows with distance between the two zones.
- New `CEC_Event_Helper::local_datetime( $raw, $timezone )`: turns a stored `_cec_start`/`_cec_end` value into a real `DateTimeImmutable` in the event's resolved timezone (`data()['timezone']` — event, then venue, then site, the same rule the event page already uses). An invalid stored zone falls back to the site timezone rather than fataling. Any future code that emits an absolute time must use this rather than `get_gmt_from_date()` or `date_i18n( 'c' )`.
- `CEC_Ical::utc_ics()` now takes the timezone and converts through `local_datetime()`; both of its callers (ICS `DTSTART`/`DTEND` and `google_calendar_url()`) pass `$data['timezone']`.
- `event_schema()` now emits `startDate`/`endDate` with the event's own UTC offset.
- Not changed: on-page display (already correct — it shows the stored wall-clock time plus the event's own zone abbreviation), all-day events (`VALUE=DATE`, no timezone involved), and the "Past" calculation and list/calendar date queries, which compare wall-clock times against the site's current time and can be off by the zone difference for a few hours around an out-of-zone event's end. That last item is a separate, smaller issue, left for a decision rather than widened into this fix.
- **Verified in a real WordPress 7.1.2 install** (PHP 8.3, SQLite; the same WordPress version as the production site) — the first change in this plugin's history checked this way rather than by the Python/mock-markup methods in `TECHNICAL_BRIEF.md` Appendix B. `php -l` passes on all 39 PHP files. With the site on America/New_York, checked the ICS file, Google Calendar link and schema.org output over HTTP for: an America/Chicago event (now `20261104T000000Z`, `-06:00`); an event with no timezone of its own (falls back to the site zone, unchanged result); an America/Los_Angeles event on a summer daylight-saving date (`PDT`, `-07:00`); an event with a corrupted stored timezone (falls back to the site zone, no error); and an all-day multi-day event (unchanged `VALUE=DATE` output). Zero PHP warnings/notices from the plugin in `debug.log` across all of the plugin's shortcodes, single event pages, both ICS feeds, the RSS feed, and the calendar/filter AJAX endpoints.

## 1.25.0

**Phase 1d — the last of Phase 1: duplicate detection and a real editor preview** ("Give editors duplicate detection, event status controls [already built], and a preview of the list card, detail page, and month view"). This completes Phase 1 of the v2 project brief.

- **Duplicate detection**: a new "Event Preview" box (wp-admin, below Event Details) and a matching section on the front-end Calendar Manager dashboard's edit form flag other events whose title is a close match (PHP's own `similar_text()`, ≥70%) **and** whose start date falls within a day of this one — a conservative heuristic flag for a human to judge, never a hard block, consistent with this project's safe-by-default standard. Deliberately excludes anything in the same recurring series (a weekly class's own occurrences legitimately share a title and land close together — that's an intentional repeat, not an accident).
- **List card preview**: the same box renders this event's real `event-card.php` markup — exactly what it will look like in Grid view — regardless of its current (possibly unpublished) status.
- **Detail page preview**: a "Preview Full Event Page" link using WordPress's own native, nonce-protected preview mechanism (`get_preview_post_link()`) — no new plugin code needed here; `is_singular( 'cec_event' )` and this plugin's own `pre_get_posts` filters were confirmed to already behave correctly for a front-end preview request.
- **Month view preview**: `render_month_html()` gained an optional `$preview_post_id` parameter that splices one specific not-yet-published event into its own real month's results (everything else in that month still has to be genuinely published) — a dashed outline marks it as "not real yet" on both the day pill and a multi-day bar. On the front-end dashboard this is fully interactive (Prev/Next/Today/click-a-date all work, for free — that page already loads `frontend.js` globally); in wp-admin, this version's own `enqueue_admin()` now also loads the public `frontend.css`/`frontend.js` (with their own localized `CEC` object) specifically so the same interactivity works there too, rather than hand-duplicating the calendar's own nav/click-to-select JS a second time into `admin.js`. The one overlap this creates — `admin.js`'s and `frontend.js`'s own separate copies of the admission/location field-toggle handler both now bind in wp-admin — is harmless: both do the identical idempotent toggle, so calling it twice has no different effect than once.
- **Real bug caught before shipping, by checking against a realistic wp-admin backdrop instead of trusting the component in isolation**: the preview box's headings and helper text were genuinely illegible — near-white text with no dark surface under it, sitting directly on wp-admin's own white meta-box background. `.cec-editor-preview` now has its own explicit dark background (reads as an intentional themed preview window, not a rendering glitch), confirmed by re-checking the same reconstructed wp-admin layout afterward.
- A second, smaller fix caught the same way: `.cec-editor-preview` wasn't in the stylesheet's own list of wrapper classes that define its local `--cec-card`/`--cec-radius`/`--cec-muted`/etc. custom properties, so the card/calendar previews nested inside it would have silently lost their own correct card/border colors. Added to that list alongside the plugin's other top-level wrappers.
- **Verified**: a faithful Python port of PHP's own `similar_text()` algorithm was run against realistic title pairs (an exact duplicate, a resubmission with a year appended, a punctuation variant, two genuinely different events with similar names, and two clearly unrelated events) to confirm the 70% threshold catches the real cases without over-flagging; the wp-admin preview box was checked against a reconstructed realistic wp-admin postbox layout (not just viewed in isolation), which is what caught both CSS issues above before shipping rather than after a live report.

**Phase 1 of the v2 brief is now complete** (1a data model, 1b Upcoming-list redesign, 1c Past/first-weekday/URL-filters/agenda, 1d duplicate detection + preview). Phase 2 (member accounts/profiles/My Calendars) and Phase 3 (shared planning/recurring tasks) remain a separate, not-yet-started, confirmed-to-need-its-own-plugin body of work per the brief's own explicit recommendation.

## 1.24.1

**Fix: a real theme-collision bug on the live site, reported with a screenshot** — the inactive "Grid" button and the "Latest First" sort toggle rendered dark/barely-legible, even though both already had `!important` on their background/color. Root cause: the live theme's own button styling uses a compound selector (e.g. `button.some-theme-class`) with `!important` too, which out-specifies a bare single-class rule like `.cec-view-btn` regardless of `!important` on either side — the exact same collision category fixed on the calendar's bars/pills in 1.21.0, this time missed on the filter bar's own buttons (including the two new ones added in 1.23.0, `.cec-filter-submit` and `.cec-sort-toggle`, which had never been hardened at all).
- Every button/select in the filter bar (`.cec-filters select`, `.cec-filter-submit`, `.cec-sort-toggle`, `.cec-view-btn`) is now scoped under `.cec-events-wrap` and has `!important` on every property defining its visual identity, matching this plugin's established hardening pattern.
- **Verified the bug was real before trusting the fix**: reconstructed the old, unscoped CSS under separate class names, loaded it against a hostile mock theme carrying the exact compound-selector-plus-`!important` pattern described above, and confirmed it reproduced the user's screenshot exactly (dark, illegible buttons) — then confirmed the new scoped rules, loaded from the actual shipped `frontend.css`, render correctly against that same hostile theme.
- **Also changed per direct request**: `[cec_events]`'s own default `view` is now `"list"` (was `"grid"`) — any existing placement that doesn't pass `view="grid"` explicitly will now show the Phase 1b list redesign by default. The Elementor "Community Events (Grid/List)" widget's own Layout control default was updated to match, for any new widget instance going forward (existing ones keep whatever was explicitly saved).

## 1.24.0

**Phase 1c: Past label, first-weekday setting, URL-encoded filters, small-screen agenda view.** All four shipped together per the already-agreed Phase 1c scope.

- **"Past" label**: new `CEC_Event_Helper::is_past()` — derived from an event's effective end (end date/time if known, otherwise its start), never a stored status. Shown as a quiet badge on the single event page (the only place a past event is still reachable, per the brief: "a past event remains on its detail URL and is labeled Past").
- The Upcoming list's (`[cec_events]`) past-event exclusion is now **end-date-aware** instead of the old crude "started within the last day" approximation — an event with an explicit end is excluded once that end has passed, not just its start; an event with no end (a Start-time-only event) is excluded once its start has passed, matching `is_past()`'s own fallback exactly so the query and the display-side label can never disagree with each other. Verified consistent against representative sample data (in-progress multi-day, no-end start-only, future, just-ended) in Python before shipping.
- **First Day of Week** (Events > Settings > Calendar Display), defaulting to Sunday, applied identically to the public and (already shared) member month grids. All 7 weekdays are selectable, not just Sun/Monday, since the underlying rotation math is no harder to support generically. Real day names (not hardcoded English strings) are generated from a known-Sunday reference date rotated to the configured start, so this is also now properly locale-aware for the first time.
- **URL-encoded filters**: `[cec_events]`'s event-type/venue/date-range/sort/view state now round-trips through the URL's own query params (`cec_event_type`, `cec_venue`, `cec_date_range`, `cec_sort`, `cec_view`) — copying or bookmarking the page URL reproduces the same result set. The initial server render reads `$_GET` directly (works even before any JS runs); the JS updates the address bar via `history.replaceState` (not `pushState` — a filter tweak doesn't belong in back-button history) after every Filter/Sort/Grid-List action. Defaults are left out of the URL entirely so the plain/unfiltered page keeps a clean link.
- **Small-screen agenda view** (`[cec_calendar]`, below the existing 700px breakpoint): replaces the compressed month grid outright with a chronological, day-by-day list of every date in the month that has an event — each showing its complete date range (never just "today's slice" of a multi-day span) — rather than just shrinking the grid's fonts/cells. Reuses the exact markup/classes the existing click-a-date detail panel already builds in JS, server-rendered this time, so no new visual language was introduced and the panel itself (redundant once the whole month is already listed) is hidden at the same breakpoint.
- **Verified**: the first-weekday offset math (`lead_blanks`) and the locale-aware header rotation were ported to Python and checked for every one of the 7 possible settings against a real month; the `is_past()`/not-past-query consistency was checked the same way. The weekday-rotated grid and the small-screen agenda were both rendered against the real production CSS in a reconstructed browser harness at desktop and mobile widths and matched expectations exactly.

## 1.23.0

**Phase 1b: the Upcoming list (`[cec_events view="list"]`) redesign** — date-range-first cards, month-grouped headers, a simplified filter bar, and a compact sort toggle. Rebuilt from the brief's own "Appendix A" reference image (re-extracted from the source `.docx`'s embedded media, not worked from memory), shown to the user as a standalone static mockup using the site's real brand tokens and Phase 1a's actual admission/location states, and only built for real after explicit sign-off on that mockup. **The month-grid calendar (`[cec_calendar]`) and the Upcoming ticker (`[cec_upcoming]`) are both untouched** — this only changes the filterable events list/grid shortcode, and only its `list` view; `view="grid"` (the existing photo-forward card grid) is unchanged.

- New `templates/parts/event-row.php` — a date-range-first row card (big month/day-range/year block, title, location + host line, type/admission badges, a quiet "Event Details" link) used only by List view. Grid view keeps the existing photo-card template (`event-card.php`) untouched.
- `CEC_Shortcodes::render_events_html()` now groups List view's results under a "Month Year" heading per the query's own sort order, so the toggle below still makes sense reversed.
- New `CEC_Event_Helper::date_block()` centralizes the big-date-block formatting (single day with its time/timezone abbreviation when known, a same-month day range, or a plain compact fallback string for the rare event spanning a calendar-month boundary) — one source of truth rather than re-deriving it in the template.
- **Filter bar simplified** from 4 dropdowns (category/organization/venue/sort) to 3 (event type/venue/a date-range preset: This Week, This Month, Next 3 Months, All Upcoming) plus an explicit **Filter** button — picking all three no longer fires three separate reloads, only one on submit. A compact **Soonest First / Latest First** toggle replaces the old sort dropdown, acting immediately like the existing Grid/List toggle rather than requiring Filter.
- New `CEC_Event_Helper::date_range_preset_end()` resolves each preset to an end timestamp (`null` for "All Upcoming" — today's existing unbounded behavior, unchanged). **Real bug caught before shipping**: PHP's relative `strtotime('next Saturday', …)` jumps a full 7 days when "today" already IS Saturday — verified in Python against every weekday including Saturday itself, then computed the day-offset directly instead so "This Week" still means "through the end of this week" even when checked on a Saturday.
- The Organization quick-filter dropdown was dropped from this bar (not part of the brief's own filter list for this view, and not shown in its reference mockup) — **not a capability loss**: every Partner Organization already has its own archive page (linked from event cards/pages) that lists all of that organization's events via the same `render_events_html()`, which still accepts an organization filter internally for that page's own use.
- Found and fixed a real CSS mismatch while cross-checking the approved mockup against this plugin's actual classes: the mockup's quiet, unfilled "Event Details" button was about to be wired to `.cec-btn-outline` — which, despite its name, is this plugin's existing *solid* hot-pink secondary-action style, not a ghost/outline button. Every row on this list has one of these buttons, so reusing the loud style would have visually overwhelmed the page in a way neither the brief's reference image nor the approved mockup showed. Added a dedicated `.cec-row-cta-btn` class instead (hardened the same way as every other interactive element in this plugin — scoped, `!important`, explicit hover/focus).
- Removed now-dead CSS (`.cec-view-list .cec-event-card`/`.cec-card-media` rules) left over from when List view rendered the photo-card template directly — List now renders `.cec-event-row` instead, so those selectors never matched anything once this version shipped.
- **Verified**: `date_block()`'s single-day/same-month/cross-month branches, the month-grouping order, and the date-range-preset end-timestamp math (including the Saturday edge case above) were each ported to Python and run against representative sample data. The real production CSS and JavaScript (not a re-implementation) were loaded into a reconstructed static harness covering every admission/location/time-mode combination plus a cancelled event and the cross-month fallback, checked at both desktop and mobile widths, and the Filter/Sort-toggle/Grid-List interactions were exercised directly and confirmed to build the correct AJAX payload.
- **Not changed, flagged rather than assumed**: the brief's own text says an Upcoming list should be the *default* view, but `[cec_events]`'s shortcode default remains `view="grid"` — flipping that would silently change the look of any existing placement on the live site that relies on the default rather than passing `view="list"` explicitly, and this session doesn't know which the user's actual page uses. Left as a decision for the user rather than guessed at.

## 1.22.0

**Phase 1a of the v2 Community Calendar & Member Planning project brief: the full event data-model rebuild** — date/time model, four-state admission model (with a safe migration), and location/place model, plus the bundled field-hygiene items the brief grouped alongside them. All of it lands across the same five places an event can be edited (wp-admin meta box, public submission form, Calendar Manager dashboard, My Events, guest email-link edit), since every one of those forms re-implements the same fields independently.

**Group A — Date/time model.**
- New per-event **Time Details** mode: Exact start/end time (unchanged default), Start time only, All day, or Schedule varies. All-day/varies events no longer show a fake "12:00 am" — the time is dropped from every public display (card, single page, calendar day-detail, the Upcoming ticker's date range) for those two modes.
- New per-event **Timezone** field (any IANA zone), defaulting to a new venue-level Timezone (Events > Venues), falling back to the site's own timezone — unchanged behavior for every event that doesn't set one explicitly. The resolved zone's abbreviation (e.g. "CDT") now shows next to public start times.
- `.ics` export and the "Add to Google Calendar" link now emit a real RFC 5545 all-day event (`DTSTART;VALUE=DATE`, with the RFC-mandated *exclusive* end date — one day after the real last day) instead of a timed event, for anything in All-day mode.
- The `.ics` importer now reads the source file's own `TZID` when present instead of always assuming the site's timezone, and sets Time Details to All day when the source file marks a date-only (`VALUE=DATE`) event.

**Group B — Four-state admission model.** Replaces the old binary "Free checkbox + price-note text" everywhere.
- New Admission states: **Free — confirmed**, **Paid** (price, currency, note, optional source link), **Price varies** (a price range), **Price not posted**.
- **Safe migration, not a guess**: every existing event's old `is_free`/price-note data was migrated once, automatically. A legacy "Free" checkbox was *never* auto-promoted to "Free — confirmed" — it migrates to "Price not posted" and is flagged with a new **Needs Price Review** admin-list filter instead, specifically because the 1.21.1 fix above confirmed that checkbox could default to checked by mistake, so an unverified "Free" is not trustworthy enough to carry forward as confirmed. A legacy price note with a parseable dollar amount migrates to Paid with that amount pre-filled; a note with no parseable number still migrates to Paid (just without a pre-filled amount); a blank legacy record migrates to Price not posted.
- The `.ics` importer now creates new events as **Price not posted** (an honest "the source file didn't say"), replacing the previous default of "Paid, pricing not provided" — the source file never actually claimed Paid either.
- Admission/price changes on any event now write to the existing (previously underused) audit log, visible in the wp-admin "Recent Activity" box.

**Group C — Location/place model.**
- New per-event **Location Type**: In Person, Online, Hybrid, or Not posted yet — each with its own public label ("Location Not Posted" replaces the old unconditional "Location TBD") and its own fields (an Online Access Link; the existing Venue/Custom-Address fields, now only shown when relevant).
- New structured City / State-Region / Country fields, both at the venue level (Events > Venues) and as a per-event override for a one-off custom address — surfaced in the Venues admin table and the front-end dashboard's Venues manager.
- Schema.org/JSON-LD output and the public Where/location text everywhere now reflect the real location type (an Online event gets `OnlineEventAttendanceMode` and a `VirtualLocation`, a Hybrid event gets both).

**Bundled field-hygiene items** (addressed in the same pass, same forms):
- Short Description's character limit raised to the spec's 1,000 characters everywhere (was 200 on the public form, uncapped/inconsistent elsewhere).
- A real **Photo Alt Text** field on every photo upload (all four front-end forms) — previously an uploaded photo's alt text was never set at all, so it silently fell back to the event title.
- Uploaded event photos are now validated server-side (JPG/PNG/GIF/WEBP only, 5MB max) with a real error message on rejection, instead of being handed to WordPress's media library unchecked.
- A new **Official Event Website** field, distinct from Host Organization Website (a recurring festival's own site vs. its host's).
- A new **Source Link** field (admin/dashboard only — editorial provenance, not public) and a **Last Updated** value (from the post's own real modified date — no new field needed).
- A real **In Review** post status, distinct from Pending (just submitted, untouched) and Draft (rejected/hidden) — selectable from the Calendar Manager dashboard and wp-admin's own status dropdown.

**Not done here, flagged honestly:** Phase 1b (Upcoming-list redesign), 1c (Past label, first-weekday setting, URL-encoded filters, small-screen agenda view), and 1d (duplicate detection, a real editor preview) are still pending, in that sequence, per the plan already agreed with the user. The per-day/per-session admission-override model for multi-day events (distinct from the simple multi-day span already shipped) remains unbuilt and unconfirmed as genuinely needed.

**Verified**: brace/paren/div balance on every touched file (no live PHP/WP environment available); the admission migration's never-auto-promote-Free rule, the corrected price-formatting ($12.50 not $12.5), and the RFC 5545 all-day exclusive-end-date math were each simulated in Python against representative data; the new admission/location field-toggle JavaScript (shared verbatim between the public-facing forms and the separate wp-admin script) was verified in a real browser against a reconstructed static harness — the first harness attempt itself had a bug (a directly-bound test listener racing ahead of the delegated production handler), caught and fixed before trusting the result, which came back fully correct afterward.

## 1.21.1

**Fix: two active violations of the v2 project brief's Phase 1 spec, found during a full requirement-by-requirement audit of the current codebase.** The brief explicitly requires running its acceptance checklist against the deployed build and documenting gaps before any further work — this was step one of that, confirmed scope with the user before touching anything, and fixed only the two items confirmed as the immediate priority (the remaining ~10 gaps — per-event timezone, the four-state admission model, time-mode, location-mode, URL-encoded filters, and others — are recorded and awaiting a sequencing decision, not fixed here).
- **"Never infer Free from blank or zero," violated**: both the native wp-admin meta box (`$m( '_cec_is_free', '1' )`) and the public submission form (`checked` hardcoded on the "This event is free" checkbox) defaulted every *new* event to Free. Fixed by defaulting both to unchecked/`'0'`. The three edit-only forms (dashboard, My Events, guest edit) were already correct — they reflect the real stored value rather than defaulting a new one, so this was confined to the two actual creation entry points.
- **"Store no placeholder time," violated**: the public submission form pre-filled Start/End with today's date at 6:00–8:00 pm, a real value a submitter could leave in place without noticing. The admin meta box was already correct (it only ever echoes the real stored value, defaulting to empty). Removed the pre-filled values from the public form's Start/End fields; both remain real, empty, submitter-filled inputs.
- **Verified**: brace/paren balance on both touched files; confirmed via direct code reading (not assumption) that the three other save/edit forms were never affected by this default, since they only ever read back an existing record's real value.

## 1.21.0

**Fix: the 1.20.0 calendar redesign shipped visually broken on the real live site, and didn't actually match the Google Calendar style it was meant to** — two real, user-reported problems, both root-caused and fixed the same day rather than patched over.

**Problem 1 — real theme collision.** A screenshot from the live site showed solid pink bars with no visible event text, and "+N more" rendered as a bordered box instead of plain text — the exact same category of bug found earlier this session on a sibling plugin (Promo Manager): the site's real theme styles `a`/`button` elements globally, and a plugin rule with equal or lower CSS specificity (or no `!important`) loses to it. Every interactive element this calendar renders (bars, pills, the day-number button, "+more", nav buttons, the Today button) is now scoped under `.cec-calendar-wrap` and hardened with `!important` on every property that defines its visual identity, with explicit `:hover`/`:focus`/`:active` coverage — verified against a deliberately hostile mock theme (`a`/`button` styled globally with `!important`, reconstructed from the actual screenshot evidence: matching background/text color on links explaining the invisible text, a bordered `button` rule explaining the boxed "+more"). Also found and fixed the same gap in `.cec-btn` — this plugin's existing, widely-used shared button class — which had everything *except* `text-decoration` hardened; a real theme's `text-decoration: underline !important` on `a` was bleeding through into every Share/Register/dashboard-action button sitewide, not just this new calendar work.

**Problem 2 — this never actually looked like Google Calendar.** Pointed out directly, then confirmed against a real Google Calendar reference screenshot: the day number belongs at the *top* of each day's box with events stacking directly beneath it inside the same bordered box — not in a separate unboxed strip above the day grid, which is what 1.20.0 actually built. Also: a continuing multi-day bar should repeat its real title on every week it spans (not a generic "continues" label), with only the end caps differing — rounded at a true start/end, a pointed chevron notch where the bar is merely clipped by the week boundary — and bars should bleed fully to the edges of their grid columns, with no gap, so a bar crossing a day boundary reads as one unbroken shape instead of two bars with a notch cut out of the middle.
- Redesigned the week grid: a per-day background/border box now spans every row of its week (day-number row + however many bar lanes), with the day number + single-day pills in a separate layer pinned to row 1, and bars in their own layer starting at row 2 — all three layers share the same grid cells and are painted in that explicit order, which is what lets the bars visually sit "inside" the bordered day boxes instead of floating above them.
- Real bug caught while building the above: a full-height box used `grid-row: 1 / -1` to span the whole week, which (confirmed directly via `getBoundingClientRect()`, not assumed) only reliably spans **explicitly** declared grid rows — this grid's rows are entirely implicit (`grid-auto-rows`, no `grid-template-rows`), so `-1` silently resolved to just row 1, leaving every bar below it rendering in uncovered implicit rows. Fixed by computing the real last line number server-side instead of relying on `-1`.
- Real bug caught verifying the chevron notch: `clip-path` wasn't applying at all on the continuation classes, because the base `.cec-cal-bar` rule's `all: unset` expands to an *explicit* `unset` for every property (including ones it never names, like `clip-path`) carrying that rule's own two-class specificity — a single-class modifier selector (`.cec-cal-bar-continues-to` alone) can't win against that regardless of source order. Fixed by chaining the modifier onto `.cec-cal-bar` itself (matching specificity) rather than leaving it standalone.
- Removed the per-bar gap in `.cec-cal-week`'s grid (`gap: 0`) and gave `.cec-cal-cell` shared `border-right`/`border-bottom` lines instead of individually-rounded cards, so the week reads as one continuous bordered grid, matching the reference.
- **Verified, this time with the DOM-measurement caveat applied correctly**: the first screenshot read after this structural change looked right by eye, but the user caught that events were still rendering outside the day boxes — confirmed via `getBoundingClientRect()` (not another screenshot guess) that the background box's real height stopped short of the bars it was supposed to contain, exactly matching the `-1` bug above. Re-verified after each fix via direct measurement (cellbg bounds contain the bars; computed `clip-path`/`border-radius`/`text-decoration` on the actual rendered elements) rather than a visual read, at both desktop and mobile widths, plus the hostile-theme pass for the collision fix.

## 1.20.0

**Feature: Calendar month view redesigned per a developer-handoff spec + mockup** — the first of several confirmed phases from a larger UX/UI brief (scoped and prioritized directly with the user rather than guessing at order; a per-event timezone field and a small-screen agenda view were confirmed as separate, later phases).
- **Color-coded by event length**: multi-day events render as a pink/secondary bar; single-day events render as a lime/primary pill — a deliberate, consistent distinction (matching a legend now shown above the grid) rather than both kinds sharing one color.
- **Compact continuation**: a multi-day bar continuing from a previous week now shows a small "↳ continues" chip tied to the same event/link, instead of repeating the full title a second time. The bar's true start still gets a "→" suffix when it continues into the following week, so either direction of a split event is legible at a glance.
- **Click any date to see everything active that day**: every day number is now a real button; clicking it (or a day's own "+N more") opens a single persistent detail panel below the grid listing every event active that date — full date range, location, host, admission badge, and an Event Details link — built from a JSON payload rendered alongside the grid, so no extra server round-trip is needed per click. Selecting a date in the middle of a multi-day event's span labels it "(in progress)".
- This replaces 1.19.0's per-week floating "+N more this week" overflow panel: the same `MAX_BAR_LANES` cap still limits how many bars stack in one week, but a capped-out event is now tracked per day (not per week) and surfaces through the same unified click-a-date panel every other event uses — one mechanism instead of two.
- New "Today" button jumps back to the current month (and selects today's date) regardless of which month is currently showing.
- **Verified**: ported the new week/lane/overflow/events-by-date logic to Python, rendered the real HTML/CSS/JS against a dataset matching the mockup's sample events plus deliberate stress cases (a week-boundary-crossing bar, two multi-day events sharing a lane with no actual column overlap, a mid-span date click), and drove it with real clicks in a browser — confirmed via direct DOM/JSON inspection (not just a screenshot glance, which read the bar layout wrong on a first pass and was caught by checking the actual `grid-column`/`grid-row` values instead) that lane assignment, the day-detail panel's content, the "(in progress)" label, and the Today button all produce the exact expected result, at both desktop and mobile widths.

## 1.19.0

**Fix: 1.18.0's uncapped multi-day bar stacking made the calendar unusable on a week with many overlapping events** — a real screenshot showed ~9 solid bars stacked above the date numbers, pushing every day cell off-screen. Confirmed directly: this wasn't a rare edge case to shrug off, this calendar genuinely carries many simultaneous national/international observances ("these are national and international events that will likely have multiples per the same period") — meaning uncapped stacking was always going to break on real usage, not just a contrived test case.
- Capped at `CEC_Shortcodes::MAX_BAR_LANES` (3) visible bar lanes per week — any further overlapping multi-day events collapse into a "+N more this week" control instead of growing the week indefinitely.
- Confirmed directly, rather than assuming a simple cap was enough on its own: with routinely many overlapping observances, a non-interactive "+N more" (hover-tooltip only, the original plan) would leave most of a busy week's content effectively undiscoverable. The control is a real, clickable, keyboard-accessible toggle (reusing this plugin's existing hidden-panel/`aria-expanded` convention, extended to keep its own "+N more"/"Show less" label text rather than a fixed generic pair) that expands an inline, scrollable list of every overflowed event — nothing is ever truly hidden, just collapsed by default. The panel floats above the day cells below it rather than pushing them down, so expanding one week's overflow never reflows the rest of the calendar.
- **Verified**: regenerated the real HTML/CSS/JS output against a realistic 9-observance overlapping dataset (plus a postponed one, to confirm status styling carries into the overflow list) and interacted with it in a real browser — confirmed the cap engages, the button expands/collapses with the correct label text via direct DOM inspection, and the day cells directly below stay in place the whole time, at both desktop and mobile widths.

## 1.18.0

**Feature: a multi-day event now renders as a single bar spanning the days it covers on the month calendar**, instead of the same chip repeating identically in every day cell it touches. Reported directly after noticing it on an imported multi-day event — "events show up as specific events per day rather than a single line spanning across the calendar." Confirmed scope first rather than assuming: single-day events keep their existing per-day chip (thumbnail + title + Free/status badge, capped at 3 with a "+N more" overflow) completely unchanged; only multi-day events change. Confirmed to keep this plugin's own dark/neon visual language rather than copying the Promo Manager calendar's specific look — the bar still reuses the proven greedy lane-assignment approach (sorted by start date, first open lane, stacked rows for genuine overlaps) since that's a structural necessity for correctness, not a visual choice.
- Each week renders as its own CSS grid (`.cec-cal-week`) so a bar can span `grid-column` across the days it's active that week — any bar lanes needed sit above that week's existing day-number/chip row, which keeps every single-day chip's look and position completely untouched rather than requiring a border/background rework of the day cells themselves.
- A bar is rounded only at an event's true start/end; a bar continuing from the previous week or into the next stays square on that side — the same "keeps going" convention already established for this kind of multi-week event span elsewhere in this project's own work.
- **Verified without a live WordPress/PHP environment (standing project constraint)**: ported the exact week-splitting/lane-assignment algorithm to Python, generated the real HTML this PHP produces for a realistic mixed dataset (overlapping multi-day events needing 3 stacked lanes, a week-boundary-crossing event, a month-boundary-crossing event, postponed/cancelled status, and ordinary single-day events), and rendered it in a real browser against the actual shipped CSS — confirmed every bar's exact `grid-column` value and rounded/square edge flags via direct DOM inspection (not just a visual read, which can be easy to misjudge by a column at a glance), at both desktop and mobile widths.

## 1.17.0

**Feature: the .ics importer can now update previously-imported events instead of always creating duplicates**, via a new "Update previously-imported events instead of creating duplicates" checkbox on the Import Events form. Direct follow-up request after actually using 1.15.0 — a re-uploaded subscribed calendar (the same source, refreshed) needs to update what's already here, not pile up a second copy of every event.
- Matches each VEVENT against a previously-imported event using the file's own stable `UID` (already captured in 1.15.0 for exactly this future use, even though dedupe wasn't built at the time). A VEVENT with no UID, or one that doesn't match anything, is still created fresh either way — this never replaces the create-new default, it's an explicit opt-in per upload.
- On a match, only the fields the source file actually provides are refreshed (date/time, location, organizer, More Info link) — deliberately leaves alone anything local that was never sourced from the file in the first place (the real Cost, a linked Venue/Partner Org term, a manually-set postponed/cancelled status). Re-syncing a calendar subscription should never silently undo a correction someone made by hand since the last import.
- Import results now report created and updated counts separately.

**Feature: the Upcoming Events ticker now shows a real date range for multi-day events** (e.g. "Oct 9–13", "Oct 30 – Nov 2", "Dec 30, 2026 – Jan 2, 2027") instead of just the start date/time with no indication the event runs for several more days — reported directly after the user noticed it on an imported multi-day event. Single-day events are unaffected (same display as before). New `CEC_Event_Helper::format_date_range()`, exposed as `date_range_display` in the shared event-data array, so other display surfaces can adopt the same compact range format later if needed.
- Verified: the date-range logic was run against same-month, cross-month, cross-year, same-day, and no-end-date cases in a Python port of the exact comparison logic, confirming each produced the expected format; brace/paren balance checked on every touched file (no live PHP environment available here, per standing project constraint).

## 1.16.1

**Fix: every event imported via .ics was showing as "Free," which was wrong for real paid events.** Reported directly by the user right after testing the 1.15.0 importer against real source files. Root cause: 1.15.0 defaulted every imported event's cost to Free, reasoning that it matched the public submission form's own default checkbox state — but that reasoning didn't actually hold up here. ICS has no price field at all, so asserting "Free" was exactly as much of an invented guess as asserting "Paid" would have been; it just happened to be the wrong one for this user's actual events.
- This plugin's cost display is strictly binary (Free or Paid) with no neutral "unknown" state, so neither default is honest on its own. Fixed by defaulting to **Paid**, but overriding the price note to an explicit "Pricing not provided in the imported file — check and update" message, so the event page states the real situation (unknown, from a source with no price field) instead of confidently claiming either Free or a price that was never actually in the file.
- The import results summary now also says this once, in plain terms, rather than repeating an identical note on every single imported event (every .ics import hits this the same way, since no .ics file carries price data at all — it's not a per-event exception worth calling out individually the way a recurring-event flag is).
- **How this slipped through the first time**: the 1.15.0 reasoning anchored on "match an existing default in this codebase" without checking whether that default's *justification* (a trusted person manually creating one new event, who'd notice and uncheck the box if it's wrong) actually applied to a different context (bulk-importing many events from a file with no price field and no per-event review step before publishing). Matching a precedent's literal value without re-checking whether its reasoning transfers is its own category of guessing.

## 1.16.0

**Feature: a new "More Info Link" field on every event**, shown as a prominent link on the event page regardless of whether a Host Organization or RSVP link is set. Direct follow-up to a user question ("is there a way to add a website to the calendar for more info?") that surfaced a real gap: the two existing URL-shaped fields (Host Organization Website, RSVP external registration link) are each conditional on something else being set too, so there was no field for a plain "click here for details" link on its own.
- Added to all five places an event's fields are edited, so this doesn't become another case of one edit path silently missing a field the others have: the Add/Edit Asset wp-admin meta box, the public Submit Event form, the Calendar Manager Dashboard's edit form, My Events, and Guest Edit.
- The .ics calendar-file importer (1.15.0) now also fills this in automatically from an uploaded file's `URL:` property, when present — many real calendar exports (Google Calendar, Eventbrite, etc.) already set one, and this plugin's own .ics *export* already emits the same property pointing at the event's permalink, so reading it back on import is the natural counterpart.
- Verified: brace/paren balance on every touched file; the importer's `URL:` parsing re-checked against the same Python simulation used to verify 1.15.0, confirming the property is read correctly alongside the rest of a VEVENT.

## 1.15.0

**Feature: Administrators and Calendar Managers can now bulk-import events from an uploaded .ics calendar file**, via a new "Import Events" tab on the front-end Calendar Manager Dashboard (`[cec_admin_dashboard]`) — the same surface used for everything else a delegated manager does without needing wp-admin access. Direct follow-up request after the existing iCal *export* (1.8.0) raised the natural question of going the other direction.
- Scoped deliberately to what can be mapped onto this plugin's real fields without guessing, confirmed with the user before building rather than assumed: restricted to Administrators/Calendar Managers only (imported events publish immediately — there's no second, less-trusted person left to review them against, unlike a public submission); a VEVENT's `LOCATION` lands in the same free-text "custom venue address" field a manually-typed venue uses, never auto-matched against an existing Venue term; an `ORGANIZER`'s display name (when the source file sets one) lands in the host-org name field the same way, never auto-linked to an existing Partner Organization; repeated uploads always create fresh events rather than trying to match/update previously-imported ones.
- **Multi-day events are a first-class case, not an afterthought** — both a single VEVENT whose `DTSTART`/`DTEND` span several real days (a timed multi-day conference) and an all-day multi-day event (RFC 5545's exclusive-`DTEND` convention, e.g. a 3-day festival) are parsed into this plugin's existing start/end datetime fields correctly, which the calendar's month view already knows how to render as a real multi-day span (no new rendering code needed).
- Recurrence in the source file (an `RRULE`, e.g. "every Tuesday") is deliberately **not** auto-expanded: this plugin's own recurrence model (ordinal/weekday child-post occurrences) doesn't cover arbitrary RRULE syntax, and guessing a mapping risked silently producing a wrong pattern. Only the first date is imported, and the import summary explicitly flags every such event so recurrence can be set manually if it should repeat here too.
- Every imported event becomes a completely normal, fully-editable event afterward — same dashboard edit form as any other event — so Location/Group/anything else can be corrected or formalized into a real Venue/Partner Org term at any time.
- New `includes/class-cec-ics-import.php`: RFC 5545 line-unfolding, VEVENT parsing (`SUMMARY`/`DESCRIPTION`/`LOCATION`/`DTSTART`/`DTEND`/`UID`/`ORGANIZER`/`RRULE`-presence), and TEXT-value unescaping. Handles UTC (`Z`-suffixed), `TZID`-qualified, and floating (zoneless) date-times, plus `VALUE=DATE` all-day values.
- **A real timezone bug caught and fixed before shipping, not after**: an early version converted each parsed date-time to the site's configured timezone (`wp_timezone()`) via a `DateTime` object, then extracted a raw Unix timestamp and formatted it back out with PHP's global `date()` — which uses the *server's* default PHP timezone, not WordPress's site setting. Many hosts run PHP itself in UTC regardless of the site's real timezone, which would have silently shifted every imported event's displayed time. Fixed by keeping the value as a `DateTime` object tied to `wp_timezone()` throughout and only ever calling `->format()` on it directly — no intermediate timestamp round-trip through the server's own default zone.
- **Verified without a live WordPress/PHP environment (standing constraint for this project)**: the parsing algorithm (line-unfolding, VEVENT splitting, property/parameter parsing, all three date-time forms, the all-day exclusive-`DTEND` math, TEXT unescaping) was ported to Python and run against a realistic sample file covering UTC, `TZID`, floating-time, single-day all-day, multi-day all-day, timed multi-day, a recurring (`RRULE`) event, a missing-title event, and a folded/wrapped `DESCRIPTION` line — every case produced the correct parsed result, including the multi-day spans this feature was specifically asked to get right. Brace/paren balance checked on every touched file.

## 1.14.3

**Fixes:**
- The registration form's first field was labeled "Your Name" but only ever set a cosmetic display name — the actual WordPress username was silently auto-generated from the email address behind the scenes, never shown to the visitor. Replaced with a real "Username" field: sanitized (`sanitize_user()`), checked for uniqueness, and used directly as the login. What's typed there is also kept as the display name (unsanitized, so "Foxxy" stays "Foxxy" rather than becoming "foxxy") — one field, honestly doing both jobs it's already presented as doing.
- `.cec-auth-form`/`.cec-submit-form` (and the other shortcode-output wrapper classes) never had their own centering margin — they relied entirely on being dropped into an Elementor column that centers things for them. This plugin's own auto-created pages (1.14.0+) are plain, non-Elementor pages, so nothing centered the form — confirmed live via a screenshot showing the registration form pinned to the left edge with the rest of the page empty. Added `margin: 0 auto` to the shared wrapper rule; verified it's a no-op for the calendar/events/upcoming widgets (they stay at 100% width either way) and only affects the two forms that actually have a fixed max-width.

## 1.14.2

**Feature: Duplicate Pages cleanup tool.** Follow-up to the 1.14.1 race-condition fix — that stopped new duplicates from being created, but did nothing about ones a site had already accumulated. Events > Settings now shows a "Clean Up Duplicate Pages" section (only when duplicates are actually detected) listing what was found; one click moves every extra copy to the Trash — not permanently deleted, restorable — keeping whichever copy each setting's URL currently points to (or the oldest copy, if none matches). Only ever acts on a page matching both the exact expected title *and* containing the expected shortcode, so it can't sweep up an unrelated page that happens to share a title.

## 1.14.1

**Fix:** the 1.14.0 page auto-creation ran multiple times on one real site, producing 5 duplicate copies each of several pages (confirmed live — a wp-admin Pages screenshot showing 5× "Calendar Admin" and 5× "Create an Account"). Cause: `maybe_upgrade()` did its work and *then* marked the site as upgraded, so several requests landing on `init` in quick succession right after the file update (browser tabs, crawlers, WP's own background requests) could each pass the "already upgraded?" check before any of them had finished — a classic check-then-act race. Fixed by marking the site upgraded *before* doing the work, and as a second layer of protection, `maybe_create_pages()` now looks for an existing page with the exact right title before creating one, linking to it instead of making another copy (this also self-heals — it means pages created by hand under the plugin's old manual-setup instructions get linked automatically too). Existing duplicate pages from before this fix aren't touched automatically — see the readme for which ones to keep.

## 1.14.0

**Fix + feature: members no longer get stranded in wp-admin.** Root cause of "register takes me to the WordPress backend to set a password and I can't get back": if Events > Settings > Accounts & Login's page URLs were left blank, every "Log In"/"Create an Account" link silently fell back to WordPress's own default screens instead of this plugin's styled ones — and separately, nothing ever redirected a *plain* member out of wp-admin if they landed there (`CEC_Roles::maybe_redirect_from_wp_admin` only ever covered delegated Calendar Managers, not regular submitters).

Fixed on both fronts:
- **Auto-provisioned pages.** `CEC_Admin_Settings::maybe_create_pages()` now creates the pages this plugin needs (Submit an Event, Log In, Create an Account, Calendar Admin, Manage My Submission, Subscribe to Events) and fills in their Settings URLs automatically — but only for whichever are still blank, never touching an already-configured one. Runs on activation and on every version upgrade, so this applies retroactively to already-running sites, not just fresh installs. New "Submit Event Page URL" setting; members are sent straight there right after registering or logging in.
- **Broadened the wp-admin escape hatch.** `maybe_redirect_from_wp_admin` now catches any non-Administrator (not just Calendar Managers) and sends them to the right front-end page. New `login_redirect` filter also prevents ever landing in wp-admin in the first place after a core WP flow this plugin doesn't otherwise control (e.g. the lost-password reset screen, which by default sends a Subscriber to wp-admin/profile.php). The admin bar is now hidden for all non-Administrators too, not just managers.

## 1.13.5

**Fix:** the Facebook icon (and its label) rendered outside the Share popover's own background/border. Cause: the popover was a 4-column CSS grid at a fixed 220px width, but `1fr` tracks don't shrink below their content's natural size — the icon circles plus longer labels needed more room than 220px actually had, so the grid grew wider than its own box and the last column spilled out past the visible background (same underlying issue as the 1.5.1 calendar-grid overflow, same fix: `minmax(0, 1fr)` tracks). That alone caused labels to wrap mid-word ("WHATSA-PP"), so also switched to 3 columns at a properly-computed width instead of 4, which fits every label on one line. Verified with a rendered before/after screenshot.

## 1.13.4

**Fix:** the Telegram share icon overflowed its circle — its arrow shape was drawn nearly edge-to-edge in its own 24x24 coordinate space (almost no margin, unlike every other share icon), and the sharp tip's rounded stroke join pushed it past the circle boundary. Confirmed visually with a rendered preview (screenshot, zoomed) before and after, not just by reasoning about coordinates — redrawn as a filled shape with the same margin the other icons use.

## 1.13.3

**Redesign: Share menu.** The single-event Share row was a wall of seven equal-weight pill buttons (Add to Calendar's two, plus Share, WhatsApp, Telegram, Facebook, X, Email, Copy Link all stacked/wrapping) — reported as genuinely bad design, not just a preference. Replaced with a single "Share" button that opens a compact popover of small circular icon buttons (matching the same circular-button treatment the calendar's prev/next nav already uses), each with a short label underneath. Also added **Text/SMS** as a share option, using the correct `sms:` link syntax for iOS vs. Android (decided server-side from the request's User Agent, no JS needed). Native share (touch devices only, per 1.13.2) is now the single "Share" button's click behavior rather than a separate button, so there's no more risk of an inconsistently-styled second button appearing.

## 1.13.2

**Fix:** a second, independent report of the same failure 1.13.1 addressed — desktop Chrome/macOS, picking Messages from the native share sheet, link visible, nothing delivered. Since native share has now failed to actually deliver on two different desktop platforms (Windows/Telegram, macOS/Messages) while showing every sign of "working" (correct picker, correct link, app opens), it's no longer offered on desktop at all — restricted to touch devices (`'ontouchstart' in window || navigator.maxTouchPoints > 0`), where the Web Share API is mature and this failure mode hasn't shown up. Desktop now always gets the direct link row (WhatsApp, Telegram, Facebook, X, Email, Copy Link), which needs no OS handoff and can't fail this way. Applies to both the single-event Share row and the event-card compact Share button.

## 1.13.1

**Fix:** the single-event Share row hid the direct link fallback whenever the native Web Share API was available, leaving only the native button. In practice that handoff isn't always reliable — reported case: desktop Chrome → Telegram's Windows share integration opened the channel picker with the link showing, "Send" was pressed, and nothing actually posted, with no way to know that failed from this site's side (the OS/target app owns everything after the handoff). The direct link row (WhatsApp, Telegram, Facebook, X, Email, Copy Link) now stays visible alongside native share instead of being replaced by it, so a flaky native handoff always has a working fallback right there.

## 1.13.0

**Feature: share an event.** Single event pages get a full share row: a "Share" button using the native Web Share API where supported (the phone/browser's own share sheet — covers WhatsApp, Telegram, Messenger, Snapchat, Messages, Mail, AirDrop, or whatever else is installed, automatically, with zero per-app integration), plus an always-visible fallback row of direct links (WhatsApp, Telegram, Facebook, X, Email, Copy Link) for browsers without native share support — those need no JS at all. Event cards (grid/list) get a compact "Share" button: native share where available, otherwise copies the link to the clipboard.

Messenger and Snapchat are deliberately not given dedicated fallback links — neither has a share URL that works reliably across desktop and mobile without the app installed or a developer account, so they're only reachable via the native share sheet on devices that support it. `CEC_Event_Helper::share_links()` builds the reliable ones (`CEC_Ical`'s calendar-link pattern, same idea).

## 1.12.0

**Feature: reusable organization/venue details.** Venues already auto-filled their address when picked from the saved list; this extends the same "set it once, reuse it" idea further:
- Partner Organization terms can now carry saved defaults — Code of Conduct, RSVP mode, RSVP link — set once under Events > Partner Organizations. Checking that organization on an event (in wp-admin's native Partner Organizations checklist, or the front-end Calendar Manager dashboard's edit form) autofills those fields, but only the ones still empty — it never overwrites something already typed.
- A "Don't see your venue? Add it" field on the wp-admin Event Details box and the manager dashboard's edit form saves a typed custom address as a real, reusable Venue term (`CEC_Term_Meta::get_or_create_venue()`), the same way "Don't see your organization? Add it" already worked for Partner Organizations — so an address only needs to be typed once.
- The manager dashboard also gained the "Don't see your organization? Add it" inline-create field it was missing (present on the public submission form and My Events, absent here until now).

Scoped to wp-admin and the Calendar Manager dashboard — not the public submission form, My Events, or guest editing, since those are for other people submitting events, not the site's own admin workflow.

## 1.11.0

**Fixes:**
- RSVP capacity race condition (technical brief gap #2): `CEC_RSVP::handle_ajax()` checked the current count and inserted in two separate steps with no locking, so two people RSVPing for the last spot at the same moment could both succeed and overbook the event. Now serialized per-event with a MySQL `GET_LOCK()`/`RELEASE_LOCK()` mutex around the check-then-insert — only taken when a capacity limit is actually set, so uncapped events (the common case) are unaffected.
- Volunteer Inquiries CSV export never got the formula-injection fix the new RSVP export shipped with last round (technical brief gap #3) — a submitted name/message/etc. starting with `=`, `+`, `-`, or `@` would be interpreted as a formula by Excel/Sheets. Now prefixes such cells with a leading `'`, same as the RSVP export.
- The two AJAX endpoints (calendar month navigation, grid/list filtering) sent no cache-control headers, so a host-level page cache could serve a stale calendar to every visitor until the cache expired — the readme's own launch checklist already warned about this but nothing enforced it in code. Both now call `nocache_headers()`.

**Feature:** RSVP reminder emails — everyone who RSVP'd gets an email ~24 hours before the event starts (hourly WP-Cron check, `CEC_RSVP::send_reminders()`), reusing the same `wp_mail()` pipeline the rest of the plugin already depends on. Each event is only reminded once (`_cec_rsvp_reminder_sent` post meta), and that flag is cleared automatically if the event's start time is later changed (e.g. rescheduled after a postpone) so the new date still gets its own reminder.

## 1.10.0

**Features (rest of the roadmap's Tier 1 quick wins):**
- **Send Test Email button** (Events > Settings). Every notification this plugin sends — guest edit links, subscription confirms, approval alerts, volunteer notifications — depends on `wp_mail()` working, with no prior way to check that without triggering a real submission. Fires one test email to the current admin and reports `wp_mail()`'s own success/failure back on the page.
- **GDPR personal-data export/erasure hooks** (`CEC_Privacy`). Registers with WordPress core's built-in Export/Erase Personal Data tools (`wp_privacy_personal_data_exporters`/`_erasers`), reaching all five places this plugin stores PII: RSVPs, the RSVP waitlist, email subscribers, volunteer inquiries, and guest-submitter emails on events. Erasure anonymizes RSVP/waitlist/volunteer records in place (clearing name/email but keeping guest counts and history), deletes subscriber rows outright (equivalent to unsubscribing), and clears a guest submitter's email plus their edit-link token from their event — the event listing itself is kept as public content.
- **Moderation audit trail** (`CEC_Audit_Log`, new `wp_cec_event_log` table). Records who approved, rejected, deleted, or postponed/cancelled an event and when — visible as "Recent Activity" in the event's own Approval box in wp-admin. Hooks the same `transition_post_status` action `CEC_Recurrence`/`CEC_Subscribers` already use for publish/unpublish/trash, skipping occurrences so approving a recurring series logs one entry, not one per generated date; postpone/cancel/reset are logged explicitly at the same four call sites that already notify subscribers of a status change.

## 1.9.1

**Fix (accessibility, WCAG 2.1 AA basics):** the calendar's month-navigation and grid/list filter results are AJAX-swapped with no announcement to screen readers — added `aria-live="polite"`/`aria-atomic="true"` to `.cec-calendar-wrap` and `.cec-events-results` (both persist across the swap, so the attributes survive it). The "More info" card toggle now has `aria-expanded`/`aria-controls`, kept in sync on click. Also added: `aria-label`s on the calendar's prev/next month buttons and the grid/list filter `<select>`s, and `aria-pressed` on the Grid/List view-toggle buttons. Scoped to what the technical brief's accessibility audit specifically flagged, not a full WCAG pass.

## 1.9.0

**Feature:** RSVP visibility and a waitlist — the technical brief's #1 known gap. New **Events > RSVP Attendees** admin screen (mirrors the existing Volunteer Inquiries screen) lists every RSVP across all events with Upcoming/Past/All tabs, event/name/email/guest-count columns, and CSV export (this new export prefixes any cell starting with `=`, `+`, `-`, or `@` to prevent CSV formula injection — the same gap flagged in the Volunteer Inquiries export, which is untouched here). When an event with a capacity limit fills up, `templates/parts/rsvp-form.php` now offers a waitlist form instead of just a "this event is at capacity" message (new `wp_cec_rsvp_waitlist` table, `CEC_RSVP::handle_waitlist_ajax()`); waitlist signups show in a second table on the same admin screen. There is no automatic "a spot opened up" notification — the plugin has no RSVP-cancellation path today to trigger one from, so this is a manual-followup MVP, noted as such in both the admin screen and the readme.

## 1.8.0

**Feature:** "Add to Calendar" + iCal export (`CEC_Ical`). Each single event page now shows "Add to Google Calendar" and "Download .ics" links (the .ics also opens directly in Apple Calendar/Outlook); a "Subscribe (iCal)" link next to the existing "Subscribe (RSS)" one gives a live .ics feed of the whole calendar. Implemented as a plain query var (`?cec_ical=1` / `?cec_ical=all`) handled on `template_redirect` rather than a registered WP feed, specifically to avoid depending on a rewrite-rules flush. Times are converted using WP's configured site timezone (`get_gmt_from_date()`), not the server's PHP default timezone.

## 1.7.0

**Feature:** schema.org/JSON-LD `Event` structured data on every single-event page (`CEC_Event_Helper::event_schema()`, emitted on `wp_head` by `CEC_Templates::output_event_schema()`) — name, description, start/end, status (scheduled/postponed/cancelled), location, organizer, image, and price/availability where determinable. This is what makes Google eligible to show event details (date, venue, price, cancelled status) directly in search results. No settings or setup required.

## 1.6.3

**Fix:** Multi-day events only ever rendered on their start day in month view (`CEC_Shortcodes::render_month_html()` bucketed events by start date only) — a 3-day festival starting Friday silently vanished from Saturday and Sunday's cells. Events are now bucketed across every day they span, clipped to the visible month, and the underlying query was widened to also catch events that overlap the month without starting in it (e.g. one that started last month and runs into this one).

## 1.6.2

**Fix:** Buttons rendered as actual `<button>` elements (form submit buttons — "Send Me an Edit Link," "Save Changes," "Log In," etc.) were still losing background/border/color to the active theme's default button styling, even after 1.6.1. The theme's rule apparently targets native `<button>`/`input[type=submit]` with higher specificity than `<a class="cec-btn">` links get, so links were fine but real buttons weren't. Fix: `background`, `border`, and `color` are now all forced with `!important` on `.cec-btn`/`.cec-btn-outline`/`.cec-btn-danger` (`assets/css/frontend.css`).

## 1.6.1

**Fix (design change):** `.cec-btn-outline` and `.cec-view-btn` previously used a transparent background with colored text/border at rest, only filling solid on `:hover`. That transparent resting state was the root cause of buttons being unreadable in some contexts. Changed so **every** button variant has a solid, filled background and dark text (`#0b0a12`) at rest, unconditionally; hover/focus only adds a glow + slight lift, never a color/background swap.

## 1.6.0

**Fixes:**
- Card layout: `.cec-card-body` is now a flex column with `margin-top: auto` on the "View Details" button so it sits at a consistent bottom edge across cards regardless of how much badge/partner/excerpt content is above it.
- Paid events now show a cost badge on cards (previously only Free events got a badge).
- Single event page showed the address twice when an event used a custom address (no saved venue) — `venue_name` falls back to `address` internally, so the template was printing the same string twice. Now only shown once.
- Button text invisible until `:hover` — first pass, added `!important` to `color` only (superseded by 1.6.1/1.6.2, which found the fuller fix).
- New-event datetime fields defaulted to an empty value, which let the browser default the minute picker to the live current minute. Submission form's start/end fields now default to 18:00/20:00 today.

**Feature — recurrence upgrade:** "Monthly (specific weekday)" rule now supports explicit multi-select: pick one or more "which week" (1st/2nd/3rd/4th/Last) **and** one or more "which day" (Sun–Sat) checkboxes; the cartesian product of both is generated as one series (e.g. 2nd + 4th Wednesday). Falls back to auto-deriving from the start date if nothing is checked, so series created before this existed keep working unchanged. New postmeta: `_cec_recurrence_ordinals`, `_cec_recurrence_weekdays` (comma-separated ints; ordinal `0` = "last"). Shared UI/logic lives in `CEC_Recurrence::render_monthly_weekday_fields()` / `sanitize_posted_ordinals_weekdays()` / `get_ordinals()` / `get_weekdays()`, called identically from all 5 places that edit recurrence (wp-admin meta box, submission form, My Events, manager dashboard, guest edit).

## 1.5.1

**Fixes (mobile):**
- Calendar grid overflowed horizontally on narrow screens — a long event title with `white-space: nowrap` forced its grid column past its `1fr` share, widening the whole grid past the viewport. Fixed with `minmax(0, 1fr)` tracks and `min-width: 0` down the flex/grid chain (`.cec-cal-cell`, `.cec-cal-events`, `.cec-cal-event-chip`, `.cec-cal-event-title`).
- List view didn't stack on mobile (kept desktop's fixed-220px-image + text-row layout, cramming text into a narrow strip). Added a `@media (max-width: 700px)` rule switching `.cec-view-list .cec-event-card` to `flex-direction: column` with a full-width image.
- Added `overflow-x: hidden` as a defensive safety net on the plugin's top-level wrapper classes — **except** `.cec-single-event`, which has a `position: sticky` sidebar that `overflow-x: hidden` on an ancestor would silently break.

## 1.5.0

**Feature:** `[cec_volunteer_form]` — a volunteer inquiry form (name, email, phone, areas of interest, availability, message), deliberately separate from the events approval system since submissions are private contact records, never published content.
- New table `wp_cec_volunteer_inquiries` (`CEC_Volunteers::create_table()`).
- New admin screen **Events > Volunteer Inquiries** (`manage_options` only — holds PII): status tabs (New/Contacted/Archived), one-click status change, CSV export.
- New settings: `volunteer_interest_areas` (comma list → checkboxes on the form), `volunteer_notify_email` (falls back to site admin email).
- Elementor widget: `CEC_Widget_Volunteer_Form`.

## 1.4.1

**Fixes:**
- Uploaded event photos were hard-cropped server-side (`add_image_size('cec_card_thumb', 400, 260, true)`), which chopped content off tall/text-heavy flyers and upscaled small images. Changed to a non-cropped proportional bounding box (`600, 600`, no hard crop), paired with `object-fit: contain` + a solid fill background on the display side so the full image always shows, letterboxed if the aspect ratio doesn't match. **Note:** only affects new uploads — existing attachments keep their already-cropped file until re-uploaded.
- Single-event and taxonomy-archive pages (rendered by the plugin's own `template_include` override, not built in Elementor) had no explicit dark background, so the active theme's default (often white) showed through. Added background/padding to `.cec-single-event`/`.cec-taxonomy-archive`, plus a `cec-plugin-page` body class (`CEC_Templates::body_class()`) so the surrounding `<body>` paints dark too — not applied to `.cec-single-event` itself via `overflow-x:hidden` (see 1.5.1 note above re: sticky sidebar).

## 1.4.0

**Features:**
- RSS feeds — no new registration needed; WordPress already generates a feed for any public post-type archive / taxonomy archive. `CEC_Feeds` adjusts the feed query (`pre_get_posts`) to sort soonest-first/upcoming-only, and enhances `the_excerpt_rss`/`the_content_feed` with a when/where/free-or-paid summary line. "Subscribe (RSS)" links added to calendar/grid/list views and org archive pages via `CEC_Feeds::subscribe_links_html()`.
- `[cec_subscribe]` — email subscriptions to "all events" and/or specific partner orgs, double opt-in (confirm-by-email before anything sends), one-click unsubscribe on every notification. New table `wp_cec_subscribers` (email, target — `'all'` or an org term_id, confirmed flag, token). Sends on: a series root going live (`transition_post_status`, skips individual occurrences to avoid one email per recurring date), and a live event's status changing to/from postponed/cancelled (called explicitly from the dedicated status-change action handlers, not from general content-edit saves that happen to also write that meta key).
- Submitters can now propose a brand-new partner org inline ("Don't see your organization? Add it") on all three submission/edit forms — creates the taxonomy term immediately (`CEC_Term_Meta::get_or_create_partner_org()`); the event itself still needs approval, but the org record is live right away for filtering/RSS/subscriptions.

## 1.3.0

**Features:**
- `[cec_login]` / `[cec_register]` — styled equivalents of wp-login.php. Registration asks only name/email/password (no username field — WP natively accepts email as a login identifier). New accounts get the site's configured default new-user role. Respects Settings > General > Membership ("Anyone can register").
- Guest submission with emailed edit links: new setting `allow_guest_submission` adds an email field to the public submission form for logged-out visitors; `[cec_manage_submission]` lets them request an edit link by email and use it to edit/postpone/cancel/withdraw — no account. Bearer-token auth (`CEC_Tokens`): raw token only ever exists in the emailed URL, only its SHA-256 hash is stored, 7-day expiry, reissued on each request. Scoped to standalone events and series roots — one specific occurrence within a series still needs a logged-in My Events session.
- New settings: `login_page_url`, `register_page_url`, `manage_submission_page_url` — resolved centrally via `CEC_Admin_Settings::login_url()`/`register_url()` so every "Log In" link in the plugin uses the custom page if configured, falling back to core WP screens otherwise.

## 1.2.0

**Features:**
- Recurring events: Weekly / Monthly (same date) / Monthly (same weekday, auto-derived from start date at this point — see 1.6.0 for the multi-select upgrade). Implemented as real child posts ("occurrences"), each tagged `_cec_recurrence_parent_id`, so every existing calendar/list/RSVP query works on them unmodified (`CEC_Recurrence`). Approving/rejecting/trashing the series root cascades to all occurrences via `transition_post_status`. Editing the root's schedule fully regenerates future occurrences; editing just its content syncs in place without touching dates or per-occurrence status (signature-hash comparison decides which).
- Postponed/cancelled event status (`_cec_event_status`: scheduled/postponed/cancelled + optional note). Badge everywhere the event appears, banner on the single page, RSVP paused while active. Does **not** require re-approval — deliberately decoupled from the content-edit flow so it's fast for urgent updates.
- `[cec_my_events]` — logged-in submitters can view/edit/postpone/cancel/withdraw their own events (grouped by series for recurring ones). Editing details resets status to Pending for re-approval; postpone/cancel does not. Same ownership-based permission model reused by the dashboard AJAX endpoint (`CEC_Dashboard_Ajax`), so no new role is needed for this.

## 1.1.0

**Features:**
- Front-end manager dashboard: new "Calendar Manager" role/capability (`cec_manage_events`, granted to Administrator automatically) that can approve/reject/edit events and manage Partner Orgs/Venues via `[cec_admin_dashboard]` without wp-admin access. `CEC_Roles` redirects that role away from wp-admin if it ever lands there, and hides the admin toolbar for it. Administrators are unaffected — this is additive, not a replacement for the existing wp-admin workflow.
- Full visual re-skin: dark background, hot-pink (`#FF50D7`) borders/labels, lime (`#E1F577`) pill CTAs, bold uppercase display type (Archivo Black). Brand colors are CSS custom properties set from Events > Settings, so the palette can be changed without editing CSS.

*(This version folds together two rounds of work that shipped without a version bump at the time — the manager dashboard and the color rebrand — corrected retroactively once versioning discipline was established as a standing practice.)*

## 1.0.0

Initial build.
- Custom post type `cec_event` + taxonomies `cec_event_type`, `cec_partner_org`, `cec_venue` (all with custom term meta — website/logo for orgs, address/maps link for venues).
- Approval workflow reuses WordPress's native `pending` → `publish` status; no custom post status needed.
- `[cec_submit_event]` front-end submission form (login required by default), `[cec_calendar]` month view, `[cec_events]` filterable grid/list, `[cec_upcoming]` scrolling widget.
- RSVP: internal (own table `wp_cec_rsvps`, optional capacity) or external link, configurable per event.
- Matching Elementor widgets for every shortcode, registered under a "Community Calendar" category.

---

## Known scope boundaries / things a future developer should know

- **Not a git repo.** No commit history — this file is the only change record. Consider initializing git if ongoing development continues.
- **RSVP** (`wp_cec_rsvps`), **subscribers** (`wp_cec_subscribers`), and **volunteer inquiries** (`wp_cec_volunteer_inquiries`) are custom tables, created via `dbDelta()`. Table creation runs on `register_activation_hook` **and** is gated behind a `cec_db_version` option checked on `init` (`CEC_Plugin::maybe_upgrade()`), since re-uploading plugin files without deactivating doesn't re-fire the activation hook.
- **Occurrences are real posts.** Any `WP_Query` against `cec_event` that doesn't explicitly want individual recurring dates should exclude them via `meta_query` on `_cec_recurrence_parent_id` (see `CEC_Recurrence::exclude_occurrences_from_admin_list()` for the pattern).
- **Guest/token auth is bearer-token, not session-based** — anyone with the emailed link can act as that submitter for 7 days. Acceptable for this use case (low-stakes, self-service, always re-requestable) but worth knowing if requirements change.
- **All `!important` usage in frontend.css is deliberate**, not accidental bloat — it exists specifically to survive conflicts with whatever active theme/page-builder styling the plugin is dropped into. Don't remove it without re-testing button visibility against the live theme.
- **Color/design tokens** are CSS custom properties (`--cec-primary`, `--cec-secondary`, etc.) set inline from Events > Settings — don't hardcode hex values in new CSS; reference the variables.
