<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class CEC_Event_Helper {

	/**
	 * Legacy admission data (a plain is_free checkbox + free-text price note)
	 * predates the four-state admission model below. Rather than migrate
	 * storage, _cec_admission_status is the new source of truth going
	 * forward and is_free is now DERIVED from it in data() — every existing
	 * template/display call site that reads $data['is_free'] keeps working
	 * unchanged.
	 */
	const ADMISSION_STATES = array( 'free_confirmed', 'paid', 'price_varies', 'not_posted' );
	const LOCATION_MODES   = array( 'in_person', 'online', 'hybrid', 'not_posted' );
	const TIME_MODES       = array( 'exact', 'start_only', 'all_day', 'varies' );

	public static function data( $post_id ) {
		$start_raw = get_post_meta( $post_id, '_cec_start', true );
		$end_raw   = get_post_meta( $post_id, '_cec_end', true );

		$location_mode = get_post_meta( $post_id, '_cec_location_mode', true );
		$location_mode = in_array( $location_mode, self::LOCATION_MODES, true ) ? $location_mode : 'in_person';

		$venue_terms = get_the_terms( $post_id, 'cec_venue' );
		$venue_name  = '';
		$maps_url    = get_post_meta( $post_id, '_cec_venue_custom_maps_url', true );
		$address     = get_post_meta( $post_id, '_cec_venue_custom_address', true );
		$city        = get_post_meta( $post_id, '_cec_venue_custom_city', true );
		$region      = get_post_meta( $post_id, '_cec_venue_custom_region', true );
		$country     = get_post_meta( $post_id, '_cec_venue_custom_country', true );
		$venue_tz    = '';

		if ( $venue_terms && ! is_wp_error( $venue_terms ) ) {
			$venue_name = $venue_terms[0]->name;
			if ( ! $maps_url ) {
				$maps_url = CEC_Term_Meta::venue_map_url( $venue_terms[0]->term_id );
			}
			if ( ! $address ) {
				$address = get_term_meta( $venue_terms[0]->term_id, 'cec_address', true );
			}
			if ( ! $city ) {
				$city = get_term_meta( $venue_terms[0]->term_id, 'cec_city', true );
			}
			if ( ! $region ) {
				$region = get_term_meta( $venue_terms[0]->term_id, 'cec_region', true );
			}
			if ( ! $country ) {
				$country = get_term_meta( $venue_terms[0]->term_id, 'cec_country', true );
			}
			$venue_tz = get_term_meta( $venue_terms[0]->term_id, 'cec_timezone', true );
		} else {
			$venue_name = $address;
		}

		if ( ! $maps_url && $address ) {
			$maps_url = 'https://www.google.com/maps/search/?api=1&query=' . rawurlencode( $address );
		}

		$city_region_country = implode( ', ', array_filter( array( $city, $region, $country ) ) );

		$timezone = get_post_meta( $post_id, '_cec_timezone', true );
		if ( ! $timezone ) {
			$timezone = $venue_tz;
		}
		if ( ! $timezone ) {
			$timezone = wp_timezone_string();
		}

		$time_mode = get_post_meta( $post_id, '_cec_time_mode', true );
		$time_mode = in_array( $time_mode, self::TIME_MODES, true ) ? $time_mode : 'exact';
		// What the visitor sees, which can differ from the stored mode: see
		// display_time_mode(). Exports (ICS/Google/schema.org) keep using
		// the stored $time_mode and the real stored times.
		$display_mode = self::display_time_mode( $start_raw, $end_raw, $time_mode );

		$admission_status = self::admission_status( $post_id );

		$partner_terms = get_the_terms( $post_id, 'cec_partner_org' );
		$partners      = array();
		if ( $partner_terms && ! is_wp_error( $partner_terms ) ) {
			foreach ( $partner_terms as $t ) {
				$partners[] = array(
					'name' => $t->name,
					'link' => get_term_link( $t ),
				);
			}
		}

		$type_terms = get_the_terms( $post_id, 'cec_event_type' );
		$types      = array();
		if ( $type_terms && ! is_wp_error( $type_terms ) ) {
			foreach ( $type_terms as $t ) {
				$types[] = $t->name;
			}
		}

		return array(
			'id'               => $post_id,
			'title'            => get_the_title( $post_id ),
			// The title exactly as entered — no wptexturize() dash/quote
			// entities. For anything that leaves the site (ICS, Google
			// Calendar link, schema.org, share links), where "&#8211;" would
			// otherwise show up literally.
			'title_plain'      => self::plain_text( get_post_field( 'post_title', $post_id, 'raw' ) ),
			'permalink'        => get_permalink( $post_id ),
			'excerpt'          => get_the_excerpt( $post_id ),
			'content'          => apply_filters( 'the_content', get_post_field( 'post_content', $post_id ) ),
			'thumb_calendar'   => get_the_post_thumbnail_url( $post_id, 'cec_calendar_thumb' ),
			'thumb_card'       => get_the_post_thumbnail_url( $post_id, 'cec_card_thumb' ),
			'start_raw'        => $start_raw,
			'start_ts'         => $start_raw ? strtotime( $start_raw ) : 0,
			'end_ts'           => $end_raw ? strtotime( $end_raw ) : 0,
			'time_mode'        => $time_mode,
			'display_time_mode' => $display_mode,
			'timezone'         => $timezone,
			'timezone_abbr'    => in_array( $display_mode, array( 'exact', 'start_only' ), true ) ? self::timezone_abbr( $timezone, $start_raw ) : '',
			'start_display'    => self::format_start_display( $start_raw, $display_mode ),
			'end_display'      => ( 'exact' === $display_mode && $end_raw ) ? date_i18n( 'g:i a', strtotime( $end_raw ) ) : '',
			'date_range_display' => self::format_date_range( $start_raw, $end_raw, $display_mode ),
			'when_display'     => self::format_when( $start_raw, $end_raw, $display_mode ),
			'host_org_name'    => get_post_meta( $post_id, '_cec_host_org_name', true ),
			'host_org_url'     => get_post_meta( $post_id, '_cec_host_org_url', true ),
			'official_website_url' => get_post_meta( $post_id, '_cec_official_website_url', true ),
			'more_info_url'    => get_post_meta( $post_id, '_cec_more_info_url', true ),
			'organizers'       => get_post_meta( $post_id, '_cec_organizers', true ),
			'location_mode'    => $location_mode,
			'venue_name'       => $venue_name,
			'address'          => $address,
			'city'             => $city,
			'region'           => $region,
			'country'          => $country,
			'city_region_country' => $city_region_country,
			'maps_url'         => $maps_url,
			'online_url'       => get_post_meta( $post_id, '_cec_online_url', true ),
			'admission_status' => $admission_status,
			'is_free'          => 'free_confirmed' === $admission_status,
			'price_amount'     => get_post_meta( $post_id, '_cec_price_amount', true ),
			'price_min'        => get_post_meta( $post_id, '_cec_price_min', true ),
			'price_max'        => get_post_meta( $post_id, '_cec_price_max', true ),
			'price_currency'   => get_post_meta( $post_id, '_cec_price_currency', true ) ? get_post_meta( $post_id, '_cec_price_currency', true ) : 'USD',
			'price_note'       => get_post_meta( $post_id, '_cec_price_note', true ),
			'price_source_url' => get_post_meta( $post_id, '_cec_price_source_url', true ),
			'source_url'       => get_post_meta( $post_id, '_cec_source_url', true ),
			'last_updated_display' => get_post_field( 'post_modified', $post_id ) ? date_i18n( 'M j, Y', strtotime( get_post_field( 'post_modified', $post_id ) ) ) : '',
			'rsvp_mode'        => get_post_meta( $post_id, '_cec_rsvp_mode', true ),
			'rsvp_url'         => get_post_meta( $post_id, '_cec_rsvp_url', true ),
			'rsvp_capacity'    => (int) get_post_meta( $post_id, '_cec_rsvp_capacity', true ),
			'rsvp_taken'       => CEC_RSVP::count_for_event( $post_id ),
			'code_of_conduct'  => get_post_meta( $post_id, '_cec_code_of_conduct', true ),
			'photo_alt'        => get_post_meta( $post_id, '_cec_photo_alt', true ),
			'partners'         => $partners,
			'types'            => $types,
			'event_status'     => self::event_status( $post_id ),
			'event_status_note' => get_post_meta( $post_id, '_cec_event_status_note', true ),
			'is_recurring_root' => ! CEC_Recurrence::is_occurrence( $post_id ) && 'none' !== get_post_meta( $post_id, '_cec_recurrence_rule', true ) && get_post_meta( $post_id, '_cec_recurrence_rule', true ),
			'is_occurrence'    => CEC_Recurrence::is_occurrence( $post_id ),
			'is_past'          => self::is_past( $start_raw ? strtotime( $start_raw ) : 0, $end_raw ? strtotime( $end_raw ) : 0 ),
		);
	}

	/**
	 * "Past" is derived from the effective end moment (end date/time if
	 * known, otherwise the start) rather than stored as its own status —
	 * per the brief: a past event isn't a different kind of record, just
	 * one whose time has already elapsed.
	 */
	public static function is_past( $start_ts, $end_ts ) {
		if ( ! $start_ts ) {
			return false;
		}
		$effective_end = $end_ts ? $end_ts : $start_ts;
		return $effective_end < current_time( 'timestamp' ); // phpcs:ignore WordPress.DateTime.CurrentTimeTimestamp
	}

	/**
	 * _cec_admission_status is the new source of truth for Cost (see the
	 * class const comment above); anything not yet migrated or not one of
	 * the four valid states safely falls back to "Price not posted" rather
	 * than guessing Free — matching the brief's explicit migration rule
	 * that a legacy ambiguous value must never be auto-promoted to Free.
	 */
	public static function admission_status( $post_id ) {
		$status = get_post_meta( $post_id, '_cec_admission_status', true );
		return in_array( $status, self::ADMISSION_STATES, true ) ? $status : 'not_posted';
	}

	/**
	 * The time portion is only meaningful when the organizer actually gave
	 * one — showing "12:00 am" for an all-day or schedule-varies event is
	 * exactly the fake-precision the brief calls out, so those modes
	 * deliberately drop the time off the stored datetime value entirely.
	 */
	/**
	 * An "exact" event stored as midnight to 11:59 pm (or to midnight) on a
	 * later day is really a run of whole days with no posted hours — the
	 * .ics import and the national-events list both store weekends that
	 * way. Showing "12:00 am – 11:59 pm" there is fake precision, so for
	 * display only, treat it as all-day. Stored data is not changed.
	 */
	private static function display_time_mode( $start_raw, $end_raw, $time_mode ) {
		if ( 'exact' !== $time_mode || ! $start_raw || ! $end_raw ) {
			return $time_mode;
		}
		$start_ts = strtotime( $start_raw );
		$end_ts   = strtotime( $end_raw );
		if ( '00:00' !== date( 'H:i', $start_ts ) || ! in_array( date( 'H:i', $end_ts ), array( '23:59', '00:00' ), true ) ) {
			return $time_mode;
		}
		if ( date( 'Y-m-d', $end_ts ) <= date( 'Y-m-d', $start_ts ) && '23:59' !== date( 'H:i', $end_ts ) ) {
			return $time_mode;
		}
		return 'all_day';
	}

	/**
	 * The single-event page's full "When" line. Unlike start_display +
	 * end_display (end *time* only), this keeps the end *date* for an event
	 * that runs over several days, e.g. "Fri, Oct 9 – Sun, Oct 11, 2026".
	 */
	private static function format_when( $start_raw, $end_raw, $time_mode ) {
		if ( ! $start_raw ) {
			return '';
		}
		$start_ts = strtotime( $start_raw );
		$end_ts   = $end_raw ? strtotime( $end_raw ) : 0;
		// A run of whole days ending at midnight really ends the day before.
		if ( $end_ts && 'all_day' === $time_mode && '00:00' === date( 'H:i', $end_ts ) && $end_ts > $start_ts ) {
			$end_ts -= DAY_IN_SECONDS;
		}

		if ( ! $end_ts || date( 'Y-m-d', $start_ts ) === date( 'Y-m-d', $end_ts ) ) {
			$line = self::format_start_display( $start_raw, $time_mode );
			if ( 'exact' === $time_mode && $end_ts ) {
				$line .= ' – ' . date_i18n( 'g:i a', $end_ts );
			}
			return $line;
		}

		if ( in_array( $time_mode, array( 'exact', 'start_only' ), true ) ) {
			$end_part = 'exact' === $time_mode ? date_i18n( 'D, M j, Y g:i a', $end_ts ) : date_i18n( 'D, M j, Y', $end_ts );
			return date_i18n( 'D, M j, Y g:i a', $start_ts ) . ' – ' . $end_part;
		}

		$start_part = date( 'Y', $start_ts ) === date( 'Y', $end_ts ) ? date_i18n( 'D, M j', $start_ts ) : date_i18n( 'D, M j, Y', $start_ts );
		$line       = $start_part . ' – ' . date_i18n( 'D, M j, Y', $end_ts );
		if ( 'varies' === $time_mode ) {
			/* translators: %s: event date range, e.g. "Fri, Oct 9 – Sun, Oct 11, 2026" */
			$line = sprintf( __( '%s (schedule varies)', 'cec' ), $line );
		}
		return $line;
	}

	/**
	 * Stored text as plain characters: tags stripped and HTML entities
	 * (&#8211;, &amp;, &#8217; …) turned back into the real characters.
	 * Used for text that leaves the site in a non-HTML format.
	 */
	public static function plain_text( $text ) {
		return trim( html_entity_decode( wp_strip_all_tags( (string) $text ), ENT_QUOTES | ENT_HTML5, 'UTF-8' ) );
	}

	/**
	 * The site name as plain text ("Central Ohio Leather & Beyond"), for
	 * email subjects/bodies, calendar files and JSON. get_bloginfo( 'name' )
	 * returns the HTML-escaped display form ("&amp;"), which showed up
	 * literally in email subjects before 1.26.2.
	 */
	public static function site_name() {
		return self::plain_text( get_bloginfo( 'name' ) );
	}

	/**
	 * The full "When" line for plain-text emails: when_display (which keeps
	 * a multi-day event's end date) plus the timezone abbreviation when
	 * times are shown. start_display alone gave only the first day.
	 */
	public static function when_text( $data ) {
		return trim( $data['when_display'] . ( $data['timezone_abbr'] ? ' ' . $data['timezone_abbr'] : '' ) );
	}

	private static function format_start_display( $start_raw, $time_mode ) {
		if ( ! $start_raw ) {
			return '';
		}
		$start_ts = strtotime( $start_raw );
		if ( 'all_day' === $time_mode ) {
			return date_i18n( 'D, M j, Y', $start_ts );
		}
		if ( 'varies' === $time_mode ) {
			/* translators: %s: event date, e.g. "Fri, Oct 9, 2026" */
			return sprintf( __( '%s (schedule varies)', 'cec' ), date_i18n( 'D, M j, Y', $start_ts ) );
		}
		return date_i18n( 'D, M j, Y g:i a', $start_ts );
	}

	/**
	 * A compact date (range) for contexts with no room for a full
	 * start/end display — the Upcoming Events ticker in particular,
	 * where a multi-day event previously showed only its start date/time
	 * with nothing indicating it ran for several more days.
	 *
	 * Single-day events keep the existing "Fri, Oct 9 6:00 pm" style
	 * (unchanged for time_mode "exact"/"start_only"); a multi-day event
	 * instead shows a date range, e.g. "Oct 9 – 13" (same month), "Oct 9 –
	 * Nov 2" (different months), or "Dec 30, 2026 – Jan 2, 2027" (different
	 * years). All-day/schedule-varies events never show a time, per
	 * format_start_display() above.
	 */
	private static function format_date_range( $start_raw, $end_raw, $time_mode = 'exact' ) {
		if ( ! $start_raw ) {
			return '';
		}
		$start_ts    = strtotime( $start_raw );
		$show_time   = in_array( $time_mode, array( 'exact', 'start_only' ), true );
		$day_format  = $show_time ? 'D, M j, Y g:i a' : 'D, M j, Y';

		if ( ! $end_raw ) {
			return date_i18n( $day_format, $start_ts );
		}
		$end_ts = strtotime( $end_raw );

		if ( date_i18n( 'Y-m-d', $start_ts ) === date_i18n( 'Y-m-d', $end_ts ) ) {
			return date_i18n( $day_format, $start_ts );
		}

		$same_year  = date_i18n( 'Y', $start_ts ) === date_i18n( 'Y', $end_ts );
		$same_month = $same_year && date_i18n( 'n', $start_ts ) === date_i18n( 'n', $end_ts );

		if ( $same_month ) {
			/* translators: 1: start day (e.g. "Oct 9"), 2: end day number (e.g. "13") */
			return sprintf( __( '%1$s–%2$s', 'cec' ), date_i18n( 'M j', $start_ts ), date_i18n( 'j', $end_ts ) );
		}
		if ( $same_year ) {
			/* translators: 1: start date (e.g. "Oct 9"), 2: end date (e.g. "Nov 2") */
			return sprintf( __( '%1$s – %2$s', 'cec' ), date_i18n( 'M j', $start_ts ), date_i18n( 'M j', $end_ts ) );
		}
		/* translators: 1: start date with year (e.g. "Dec 30, 2026"), 2: end date with year (e.g. "Jan 2, 2027") */
		return sprintf( __( '%1$s – %2$s', 'cec' ), date_i18n( 'M j, Y', $start_ts ), date_i18n( 'M j, Y', $end_ts ) );
	}

	/**
	 * The split month/day-range/year-weekday-time pieces behind the
	 * Upcoming list's "date-range-first" card — a big day number needs its
	 * own month/year lines around it, which date_range_display()'s single
	 * compact string isn't built to split back apart. Degrades to that same
	 * compact string (with no separate month/year) for the rare event that
	 * spans a calendar-month boundary, rather than contorting a "big
	 * number" to fit two different months.
	 */
	public static function date_block( $data ) {
		if ( ! $data['start_ts'] ) {
			return array( 'month' => '', 'days' => '', 'year_line' => '' );
		}
		$start_ts   = $data['start_ts'];
		$end_ts     = $data['end_ts'] ? $data['end_ts'] : $start_ts;
		$same_day   = date_i18n( 'Y-m-d', $start_ts ) === date_i18n( 'Y-m-d', $end_ts );
		$same_month = date_i18n( 'Y-m', $start_ts ) === date_i18n( 'Y-m', $end_ts );

		if ( $same_day ) {
			$suffix = '';
			if ( 'varies' === $data['display_time_mode'] ) {
				$suffix = ' · ' . __( 'Schedule varies', 'cec' );
			} elseif ( in_array( $data['display_time_mode'], array( 'exact', 'start_only' ), true ) ) {
				$suffix = ' · ' . date_i18n( 'g:i a', $start_ts ) . ( $data['timezone_abbr'] ? ' ' . $data['timezone_abbr'] : '' );
			}
			return array(
				'month'     => date_i18n( 'F', $start_ts ),
				'days'      => date_i18n( 'j', $start_ts ),
				'year_line' => date_i18n( 'Y', $start_ts ) . ' · ' . date_i18n( 'D', $start_ts ) . $suffix,
			);
		}

		if ( $same_month ) {
			return array(
				'month'     => date_i18n( 'F', $start_ts ),
				/* translators: 1: start day number, 2: end day number */
				'days'      => sprintf( __( '%1$s–%2$s', 'cec' ), date_i18n( 'j', $start_ts ), date_i18n( 'j', $end_ts ) ),
				/* translators: 1: year, 2: start weekday abbr, 3: end weekday abbr */
				'year_line' => sprintf( __( '%1$s · %2$s–%3$s', 'cec' ), date_i18n( 'Y', $start_ts ), date_i18n( 'D', $start_ts ), date_i18n( 'D', $end_ts ) ),
			);
		}

		return array( 'month' => '', 'days' => $data['date_range_display'], 'year_line' => '' );
	}

	/**
	 * The short abbreviation (e.g. "CDT", "PST") for an IANA timezone name
	 * at a given moment — shown next to a public start time so a visitor in
	 * a different timezone isn't misled into reading it as their own local
	 * time. Falls back to an empty string for an invalid/unrecognized zone
	 * rather than fatal — a bad stored value should degrade gracefully.
	 */
	private static function timezone_abbr( $timezone, $start_raw ) {
		if ( ! $timezone || ! $start_raw ) {
			return '';
		}
		try {
			$dt = new DateTime( str_replace( 'T', ' ', $start_raw ), new DateTimeZone( $timezone ) );
			return $dt->format( 'T' );
		} catch ( Exception $e ) {
			return '';
		}
	}

	/**
	 * A stored "local" datetime string (_cec_start/_cec_end: the event's own
	 * wall-clock time, no offset of its own) as a real point in time in the
	 * event's resolved timezone (data()['timezone']: event, then venue, then
	 * site). Anything that leaves the site with an absolute time — ICS, the
	 * Google Calendar link, schema.org — must go through this, never through
	 * get_gmt_from_date(), which assumes the *site's* timezone and is wrong
	 * for any event set to a different one. An invalid stored zone falls
	 * back to the site timezone rather than fataling. Returns null if empty.
	 */
	public static function local_datetime( $raw, $timezone ) {
		if ( ! $raw ) {
			return null;
		}
		try {
			$tz = new DateTimeZone( $timezone ? $timezone : wp_timezone_string() );
		} catch ( Exception $e ) {
			$tz = wp_timezone();
		}
		try {
			return new DateTimeImmutable( str_replace( 'T', ' ', $raw ), $tz );
		} catch ( Exception $e ) {
			return null;
		}
	}

	public static function event_status( $post_id ) {
		$status = get_post_meta( $post_id, '_cec_event_status', true );
		return in_array( $status, array( 'postponed', 'cancelled' ), true ) ? $status : 'scheduled';
	}

	/**
	 * The four-state admission model's display precedence (postponed/
	 * cancelled status always wins; otherwise Free confirmed / Paid /
	 * Price varies / Price not posted each get their own label and class)
	 * — centralized here so the calendar day-detail panel, the event card,
	 * and the single-event page all show the identical label/styling
	 * without duplicating the logic.
	 */
	public static function admission_badge( $data ) {
		if ( 'scheduled' !== $data['event_status'] ) {
			return array(
				'label' => ucfirst( $data['event_status'] ),
				'class' => 'cec-badge-' . $data['event_status'],
			);
		}
		switch ( $data['admission_status'] ) {
			case 'free_confirmed':
				return array( 'label' => __( 'Free', 'cec' ), 'class' => 'cec-badge-free' );
			case 'price_varies':
				$label = ( $data['price_min'] || $data['price_max'] )
					? self::format_price_range( $data )
					: __( 'Price Varies', 'cec' );
				return array( 'label' => $label, 'class' => 'cec-badge-varies' );
			case 'paid':
				$label = $data['price_amount'] ? self::format_price( $data['price_amount'], $data['price_currency'] ) : __( 'Paid', 'cec' );
				if ( $data['price_note'] && ! self::note_repeats_price( $data['price_note'], $data['price_amount'] ) ) {
					$label .= ' — ' . $data['price_note'];
				}
				return array( 'label' => $label, 'class' => 'cec-badge-paid' );
			case 'not_posted':
			default:
				return array( 'label' => __( 'Price Not Posted', 'cec' ), 'class' => 'cec-badge-not-posted' );
		}
	}

	/**
	 * True when a price note says nothing beyond the amount itself ("$20",
	 * "20", "$20.00", "20 USD") — the Phase 1a migration copied the amount
	 * out of the old free-text note and kept the note, which displayed as
	 * "$20 — $20". A note with any other words ("$20 at the door") is kept.
	 */
	private static function note_repeats_price( $note, $amount ) {
		if ( '' === (string) $amount ) {
			return false;
		}
		$bare = preg_replace( '/^\$?\s*([0-9]+(?:\.[0-9]{1,2})?)\s*(usd)?$/i', '$1', trim( $note ) );
		return is_numeric( $bare ) && (float) $bare === (float) $amount;
	}

	public static function format_price( $amount, $currency = 'USD' ) {
		$float  = (float) $amount;
		// Whole-dollar amounts show with no decimals ("$10"); anything with
		// real cents keeps both digits ("$12.50") rather than the naive
		// trailing-zero-strip that would otherwise turn $12.50 into the
		// confusing "$12.5".
		$amount = ( floor( $float ) === $float ) ? number_format( $float, 0 ) : number_format( $float, 2 );
		return 'USD' === $currency ? '$' . $amount : $amount . ' ' . $currency;
	}

	private static function format_price_range( $data ) {
		if ( $data['price_min'] && $data['price_max'] ) {
			/* translators: 1: low price (e.g. "$5"), 2: high price (e.g. "$20") */
			return sprintf( __( '%1$s–%2$s', 'cec' ), self::format_price( $data['price_min'], $data['price_currency'] ), self::format_price( $data['price_max'], $data['price_currency'] ) );
		}
		$known = $data['price_min'] ? $data['price_min'] : $data['price_max'];
		/* translators: %s: a price, e.g. "$10" */
		return sprintf( __( 'From %s', 'cec' ), self::format_price( $known, $data['price_currency'] ) );
	}

	/**
	 * A short, consistent "Where" string — used by the single-event page,
	 * the calendar day-detail panel, and .ics export so the four location
	 * modes (in person / online / hybrid / not posted) never have to be
	 * re-interpreted ad hoc at each call site.
	 */
	public static function location_display( $data ) {
		$venue = $data['venue_name'] ? $data['venue_name'] : $data['address'];
		if ( $venue && $data['city_region_country'] ) {
			$venue .= ' — ' . $data['city_region_country'];
		}

		switch ( $data['location_mode'] ) {
			case 'online':
				return array(
					'label'      => __( 'Online', 'cec' ),
					'detail'     => '',
					'online_url' => $data['online_url'],
				);
			case 'hybrid':
				return array(
					'label'      => __( 'In Person & Online', 'cec' ),
					'detail'     => $venue,
					'online_url' => $data['online_url'],
				);
			case 'not_posted':
				return array(
					'label'      => __( 'Location Not Posted', 'cec' ),
					'detail'     => '',
					'online_url' => '',
				);
			case 'in_person':
			default:
				return array(
					'label'      => $venue ? $venue : __( 'Location Not Posted', 'cec' ),
					'detail'     => '',
					'online_url' => '',
				);
		}
	}

	/**
	 * Builds a schema.org/JSON-LD Event array from an already-assembled
	 * data() array, for search engines' rich-result eligibility.
	 */
	public static function event_schema( $data ) {
		$status_map = array(
			'scheduled' => 'https://schema.org/EventScheduled',
			'postponed' => 'https://schema.org/EventPostponed',
			'cancelled' => 'https://schema.org/EventCancelled',
		);

		$description = self::plain_text( $data['excerpt'] ? $data['excerpt'] : $data['content'] );

		$schema = array(
			'@context'            => 'https://schema.org',
			'@type'               => 'Event',
			'name'                => $data['title_plain'],
			'url'                 => $data['permalink'],
			'eventAttendanceMode' => self::schema_attendance_mode( $data['location_mode'] ),
			'eventStatus'         => isset( $status_map[ $data['event_status'] ] ) ? $status_map[ $data['event_status'] ] : $status_map['scheduled'],
		);

		if ( $description ) {
			$schema['description'] = $description;
		}
		// date_i18n( 'c' ) would stamp the site's UTC offset onto the event's
		// wall-clock time — wrong for any event in a different timezone.
		$start_dt = self::local_datetime( $data['start_raw'], $data['timezone'] );
		$end_dt   = self::local_datetime( get_post_meta( $data['id'], '_cec_end', true ), $data['timezone'] );
		if ( $start_dt ) {
			$schema['startDate'] = $start_dt->format( 'c' );
		}
		if ( $end_dt ) {
			$schema['endDate'] = $end_dt->format( 'c' );
		}
		if ( $data['thumb_card'] ) {
			$schema['image'] = array( $data['thumb_card'] );
		}

		if ( 'online' === $data['location_mode'] && $data['online_url'] ) {
			$schema['location'] = array(
				'@type' => 'VirtualLocation',
				'url'   => $data['online_url'],
			);
		} elseif ( $data['venue_name'] || $data['address'] ) {
			$place = array(
				'@type' => 'Place',
				'name'  => $data['venue_name'] ? $data['venue_name'] : $data['address'],
			);
			if ( $data['address'] ) {
				$place['address'] = $data['address'];
			}
			$schema['location'] = $place;
			if ( 'hybrid' === $data['location_mode'] && $data['online_url'] ) {
				$schema['location'] = array( $place, array( '@type' => 'VirtualLocation', 'url' => $data['online_url'] ) );
			}
		} else {
			// Google's guidelines expect a location on an offline event; fall back
			// to the site itself rather than omit it when no venue/address is set.
			$schema['location'] = array(
				'@type' => 'Place',
				'name'  => self::site_name(),
				'url'   => home_url( '/' ),
			);
		}

		$organizer_name = $data['host_org_name'] ? $data['host_org_name'] : self::site_name();
		$schema['organizer'] = array(
			'@type' => 'Organization',
			'name'  => $organizer_name,
		);
		if ( $data['host_org_url'] ) {
			$schema['organizer']['url'] = $data['host_org_url'];
		}

		$sold_out = $data['rsvp_capacity'] > 0 && $data['rsvp_taken'] >= $data['rsvp_capacity'];
		if ( 'free_confirmed' === $data['admission_status'] ) {
			$schema['offers'] = array(
				'@type'         => 'Offer',
				'price'         => '0',
				'priceCurrency' => 'USD',
				'availability'  => $sold_out ? 'https://schema.org/SoldOut' : 'https://schema.org/InStock',
				'url'           => $data['permalink'],
			);
		} elseif ( 'paid' === $data['admission_status'] && $data['price_amount'] ) {
			$schema['offers'] = array(
				'@type'         => 'Offer',
				'price'         => $data['price_amount'],
				'priceCurrency' => $data['price_currency'],
				'availability'  => $sold_out ? 'https://schema.org/SoldOut' : 'https://schema.org/InStock',
				'url'           => $data['permalink'],
			);
		}

		return $schema;
	}

	private static function schema_attendance_mode( $location_mode ) {
		switch ( $location_mode ) {
			case 'online':
				return 'https://schema.org/OnlineEventAttendanceMode';
			case 'hybrid':
				return 'https://schema.org/MixedEventAttendanceMode';
			default:
				return 'https://schema.org/OfflineEventAttendanceMode';
		}
	}

	public static function type_badge_class( $type_name ) {
		return 'cec-badge-' . sanitize_title( $type_name );
	}

	/**
	 * The Upcoming list's simplified date-range filter is a small set of
	 * presets (not an open date picker) — this maps each one to the end of
	 * its window as a timestamp, or null for "All Upcoming" (no upper
	 * bound at all, today's existing behavior).
	 */
	public static function date_range_preset_end( $preset ) {
		$now = current_time( 'timestamp' ); // phpcs:ignore WordPress.DateTime.CurrentTimeTimestamp
		switch ( $preset ) {
			case 'this_week':
				// PHP's relative "next Saturday" jumps a full 7 days when
				// today already IS Saturday — computing the day offset
				// directly instead keeps "This Week" meaning "through the
				// end of this week" even when run on a Saturday.
				$days_until_saturday = 6 - (int) date( 'w', $now );
				return strtotime( "+{$days_until_saturday} days 23:59:59", $now );
			case 'this_month':
				return strtotime( 'last day of this month 23:59:59', $now );
			case 'next_3_months':
				return strtotime( '+3 months', $now );
			case 'all_upcoming':
			default:
				return null;
		}
	}

	/**
	 * Phase 1d: "Give editors duplicate detection." A conservative,
	 * title-similarity + date-proximity heuristic — not a hard block, just
	 * a flag for a human to judge, consistent with this project's
	 * safe-by-default-automation standard. Deliberately excludes anything
	 * in the same recurring series as this event (same parent, or this
	 * event's own parent): a weekly series' own occurrences legitimately
	 * share the same title and land close together in time, and are
	 * already an intentional repeat, not an accidental duplicate.
	 *
	 * @return array[] Each: id, title, start_display, edit_link, percent.
	 */
	public static function find_possible_duplicates( $post_id ) {
		$data = self::data( $post_id );
		if ( ! $data['start_ts'] ) {
			return array();
		}

		$own_parent_id = CEC_Recurrence::is_occurrence( $post_id ) ? CEC_Recurrence::get_parent_id( $post_id ) : $post_id;
		// Plain title: the display title's "&#8211;" would add "8211" to the
		// words being compared and lower the match score.
		$own_title     = self::normalize_title_for_matching( $data['title_plain'] );
		if ( '' === $own_title ) {
			return array();
		}

		$window_start = date( 'Y-m-d\TH:i', $data['start_ts'] - DAY_IN_SECONDS );
		$window_end   = date( 'Y-m-d\TH:i', $data['start_ts'] + DAY_IN_SECONDS );

		$candidates = get_posts(
			array(
				'post_type'      => 'cec_event',
				'post_status'    => array( 'publish', 'pending', 'draft', 'cec_in_review', 'future', 'private' ),
				'posts_per_page' => 50,
				'post__not_in'   => array( $post_id ),
				'meta_query'     => array( // phpcs:ignore WordPress.DB.SlowDBQuery
					array(
						'key'     => '_cec_start',
						'value'   => array( $window_start, $window_end ),
						'compare' => 'BETWEEN',
						'type'    => 'DATETIME',
					),
				),
			)
		);

		$matches = array();
		foreach ( $candidates as $candidate ) {
			$candidate_parent_id = CEC_Recurrence::is_occurrence( $candidate->ID ) ? CEC_Recurrence::get_parent_id( $candidate->ID ) : $candidate->ID;
			if ( $candidate_parent_id === $own_parent_id ) {
				continue;
			}

			$candidate_title = self::normalize_title_for_matching( $candidate->post_title );
			if ( '' === $candidate_title ) {
				continue;
			}

			similar_text( $own_title, $candidate_title, $percent );
			if ( $percent < 70 ) {
				continue;
			}

			$candidate_data = self::data( $candidate->ID );
			// No edit_link here on purpose — a wp-admin link is useless to
			// a front-end-only Calendar Manager, and the dashboard's own
			// edit link needs that page's own permalink to build. Each
			// caller (admin meta box vs. front-end dashboard) builds
			// whichever link makes sense for where it's rendering.
			$matches[] = array(
				'id'            => $candidate->ID,
				'title'         => $candidate->post_title,
				'start_display' => $candidate_data['start_display'],
				'status'        => $candidate->post_status,
				'percent'       => (int) round( $percent ),
			);
		}

		return $matches;
	}

	private static function normalize_title_for_matching( $title ) {
		$title = strtolower( $title );
		$title = preg_replace( '/[^a-z0-9]+/', ' ', $title );
		return trim( $title );
	}

	/**
	 * Phase 1d: "a preview of the list card, detail page, and month view"
	 * before publishing — one shared renderer (not duplicated across the
	 * wp-admin meta box and the front-end dashboard edit form) for the
	 * possible-duplicates warning plus all three previews. $context picks
	 * the right kind of "review this" link for a flagged duplicate, since
	 * a front-end-only Calendar Manager can't use a wp-admin URL and
	 * vice-versa isn't meaningful either; $dashboard_url is only needed
	 * when $context is 'dashboard'.
	 */
	public static function render_editor_preview( $post_id, $context = 'admin', $dashboard_url = '' ) {
		if ( 'cec_event' !== get_post_type( $post_id ) ) {
			return '';
		}
		$data       = self::data( $post_id );
		$duplicates = self::find_possible_duplicates( $post_id );
		$view       = 'grid'; // in scope for templates/parts/event-card.php below.

		ob_start();
		?>
		<div class="cec-editor-preview">
			<?php
			// 1.47.0: notes from the Telegram intake (CEC_Intake_API).
			$intake_notes   = array_filter( (array) get_post_meta( $post_id, '_cec_intake_notes', true ) );
			$intake_sources = array_filter( (array) get_post_meta( $post_id, '_cec_intake_source_url' ) );
			if ( $intake_notes || $intake_sources ) :
				?>
				<div class="cec-notice cec-notice-error cec-intake-notes">
					<p><strong><?php esc_html_e( 'Imported automatically from a Telegram post. Check everything before approving, especially:', 'cec' ); ?></strong></p>
					<?php if ( $intake_notes ) : ?>
						<ul style="margin:0;">
							<?php foreach ( $intake_notes as $intake_note ) : ?>
								<li><?php echo esc_html( $intake_note ); ?></li>
							<?php endforeach; ?>
						</ul>
					<?php endif; ?>
					<?php if ( $intake_sources ) : ?>
						<p><?php esc_html_e( 'Source posts:', 'cec' ); ?>
							<?php foreach ( $intake_sources as $intake_source ) : ?>
								<a href="<?php echo esc_url( $intake_source ); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html( $intake_source ); ?></a>
							<?php endforeach; ?>
						</p>
					<?php endif; ?>
				</div>
			<?php endif; ?>
			<?php if ( ! empty( $duplicates ) ) : ?>
				<div class="cec-notice cec-notice-error">
					<p><strong><?php esc_html_e( 'Possible duplicate events found nearby in time:', 'cec' ); ?></strong></p>
					<ul style="margin:0;">
						<?php foreach ( $duplicates as $dup ) : ?>
							<?php
							$review_url = 'admin' === $context
								? get_edit_post_link( $dup['id'] )
								: add_query_arg( array( 'cec_view' => 'edit', 'cec_edit' => $dup['id'] ), $dashboard_url );
							?>
							<li>
								<?php
								printf(
									/* translators: 1: candidate event title, 2: its start date, 3: its status, 4: title-similarity percent */
									esc_html__( '%1$s — %2$s (%3$s, %4$d%% title match)', 'cec' ),
									esc_html( $dup['title'] ),
									esc_html( $dup['start_display'] ),
									esc_html( ucfirst( $dup['status'] ) ),
									(int) $dup['percent']
								);
								?>
								— <a href="<?php echo esc_url( $review_url ); ?>"><?php esc_html_e( 'Review', 'cec' ); ?></a>
							</li>
						<?php endforeach; ?>
					</ul>
				</div>
			<?php endif; ?>

			<h4><?php esc_html_e( 'List Card Preview', 'cec' ); ?></h4>
			<div class="cec-editor-preview-card">
				<?php include CEC_DIR . 'templates/parts/event-card.php'; ?>
			</div>

			<p>
				<a class="cec-btn cec-btn-small cec-btn-outline" href="<?php echo esc_url( get_preview_post_link( $post_id ) ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'Preview Full Event Page', 'cec' ); ?> &rarr;</a>
			</p>

			<?php if ( $data['start_ts'] ) : ?>
				<h4><?php esc_html_e( 'Month View Preview', 'cec' ); ?></h4>
				<p class="description"><?php esc_html_e( 'Dashed outline marks this not-yet-published event.', 'cec' ); ?></p>
				<div class="cec-calendar-wrap cec-editor-preview-calendar" data-month="<?php echo esc_attr( date_i18n( 'n', $data['start_ts'] ) ); ?>" data-year="<?php echo esc_attr( date_i18n( 'Y', $data['start_ts'] ) ); ?>">
					<?php echo CEC_Shortcodes::render_month_html( (int) date_i18n( 'n', $data['start_ts'] ), (int) date_i18n( 'Y', $data['start_ts'] ), $post_id ); // phpcs:ignore ?>
				</div>
			<?php endif; ?>
		</div>
		<?php
		return ob_get_clean();
	}

	public static function is_valid_timezone( $timezone ) {
		return $timezone && in_array( $timezone, timezone_identifiers_list(), true );
	}

	/**
	 * The Phase 1a date/time, admission, and location fields are identical
	 * across all five places an event can be edited (wp-admin meta box,
	 * public submission form, Calendar Manager dashboard, My Events, guest
	 * email-link edit) — centralized here so that logic exists exactly
	 * once instead of five times. Each caller still owns its own simpler
	 * legacy fields (title/excerpt/venue/etc.) exactly as before; this only
	 * covers the new Phase 1a meta.
	 */
	public static function save_phase1a_fields( $post_id, $source = null ) {
		// 1.47.0: $source lets code (the intake API) save through the same
		// checks as the forms. It is read like $_POST, so pass it slashed.
		$in = null === $source ? $_POST : (array) $source; // phpcs:ignore WordPress.Security.NonceVerification.Missing
		$time_mode = isset( $in['cec_time_mode'] ) ? sanitize_key( wp_unslash( $in['cec_time_mode'] ) ) : 'exact';
		update_post_meta( $post_id, '_cec_time_mode', in_array( $time_mode, self::TIME_MODES, true ) ? $time_mode : 'exact' );

		if ( isset( $in['cec_timezone'] ) ) {
			$tz = sanitize_text_field( wp_unslash( $in['cec_timezone'] ) );
			update_post_meta( $post_id, '_cec_timezone', self::is_valid_timezone( $tz ) ? $tz : '' );
		}

		$admission     = isset( $in['cec_admission_status'] ) ? sanitize_key( wp_unslash( $in['cec_admission_status'] ) ) : 'not_posted';
		$admission     = in_array( $admission, self::ADMISSION_STATES, true ) ? $admission : 'not_posted';
		$old_admission = self::admission_status( $post_id );
		update_post_meta( $post_id, '_cec_admission_status', $admission );
		update_post_meta( $post_id, '_cec_is_free', 'free_confirmed' === $admission ? '1' : '0' );
		update_post_meta( $post_id, '_cec_price_amount', isset( $in['cec_price_amount'] ) ? sanitize_text_field( wp_unslash( $in['cec_price_amount'] ) ) : '' );
		update_post_meta( $post_id, '_cec_price_min', isset( $in['cec_price_min'] ) ? sanitize_text_field( wp_unslash( $in['cec_price_min'] ) ) : '' );
		update_post_meta( $post_id, '_cec_price_max', isset( $in['cec_price_max'] ) ? sanitize_text_field( wp_unslash( $in['cec_price_max'] ) ) : '' );
		$currency = ! empty( $in['cec_price_currency'] ) ? strtoupper( sanitize_text_field( wp_unslash( $in['cec_price_currency'] ) ) ) : 'USD';
		update_post_meta( $post_id, '_cec_price_currency', $currency );
		if ( isset( $in['cec_price_source_url'] ) ) {
			update_post_meta( $post_id, '_cec_price_source_url', esc_url_raw( wp_unslash( $in['cec_price_source_url'] ) ) );
		}
		delete_post_meta( $post_id, '_cec_price_needs_review' );
		if ( $old_admission !== $admission ) {
			CEC_Audit_Log::log( $post_id, 'admission_changed', $old_admission . ' → ' . $admission );
		}

		$location_mode = isset( $in['cec_location_mode'] ) ? sanitize_key( wp_unslash( $in['cec_location_mode'] ) ) : 'in_person';
		update_post_meta( $post_id, '_cec_location_mode', in_array( $location_mode, self::LOCATION_MODES, true ) ? $location_mode : 'in_person' );
		if ( isset( $in['cec_online_url'] ) ) {
			update_post_meta( $post_id, '_cec_online_url', esc_url_raw( wp_unslash( $in['cec_online_url'] ) ) );
		}
		foreach ( array( 'cec_venue_custom_city' => '_cec_venue_custom_city', 'cec_venue_custom_region' => '_cec_venue_custom_region', 'cec_venue_custom_country' => '_cec_venue_custom_country' ) as $post_key => $meta_key ) {
			if ( isset( $in[ $post_key ] ) ) {
				update_post_meta( $post_id, $meta_key, sanitize_text_field( wp_unslash( $in[ $post_key ] ) ) );
			}
		}

		if ( isset( $in['cec_official_website_url'] ) ) {
			update_post_meta( $post_id, '_cec_official_website_url', esc_url_raw( wp_unslash( $in['cec_official_website_url'] ) ) );
		}
		if ( isset( $in['cec_source_url'] ) ) {
			update_post_meta( $post_id, '_cec_source_url', esc_url_raw( wp_unslash( $in['cec_source_url'] ) ) );
		}
		if ( isset( $in['cec_photo_alt'] ) ) {
			$alt = sanitize_text_field( wp_unslash( $in['cec_photo_alt'] ) );
			update_post_meta( $post_id, '_cec_photo_alt', $alt );
			$thumb_id = get_post_thumbnail_id( $post_id );
			if ( $thumb_id ) {
				update_post_meta( $thumb_id, '_wp_attachment_image_alt', $alt );
			}
		}
	}

	/**
	 * Validates and handles an uploaded event photo from any of the
	 * front-end forms — MIME type and size are checked explicitly (rather
	 * than left entirely to media_handle_upload(), which accepts anything
	 * WordPress itself allows, a broader set than a flyer/photo upload
	 * should) before the attachment is created, so a bad file never
	 * silently becomes the featured image with no feedback to the
	 * submitter. Returns the new attachment ID, null if nothing was
	 * uploaded, or a WP_Error whose code matches photo_error_message()
	 * below.
	 */
	public static function handle_photo_upload( $post_id, $file_key = 'cec_photo' ) {
		if ( empty( $_FILES[ $file_key ]['name'] ) ) {
			return null;
		}
		if ( UPLOAD_ERR_OK !== $_FILES[ $file_key ]['error'] ) {
			return new WP_Error( 'upload_failed', self::photo_error_message( 'upload_failed' ) );
		}
		if ( $_FILES[ $file_key ]['size'] > 5 * MB_IN_BYTES ) {
			return new WP_Error( 'too_large', self::photo_error_message( 'too_large' ) );
		}

		$allowed  = array( 'image/jpeg', 'image/png', 'image/gif', 'image/webp' );
		$filetype = wp_check_filetype_and_ext( $_FILES[ $file_key ]['tmp_name'], $_FILES[ $file_key ]['name'] );
		if ( empty( $filetype['type'] ) || ! in_array( $filetype['type'], $allowed, true ) ) {
			return new WP_Error( 'bad_type', self::photo_error_message( 'bad_type' ) );
		}

		require_once ABSPATH . 'wp-admin/includes/image.php';
		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';
		$attachment_id = media_handle_upload( $file_key, $post_id );
		if ( is_wp_error( $attachment_id ) ) {
			return new WP_Error( 'upload_failed', self::photo_error_message( 'upload_failed' ) );
		}
		set_post_thumbnail( $post_id, $attachment_id );

		$alt = isset( $_POST['cec_photo_alt'] ) ? sanitize_text_field( wp_unslash( $_POST['cec_photo_alt'] ) ) : '';
		if ( $alt ) {
			update_post_meta( $attachment_id, '_wp_attachment_image_alt', $alt );
		}
		return $attachment_id;
	}

	public static function photo_error_message( $error_code ) {
		$map = array(
			'too_large'     => __( 'That photo is too large — please use a file under 5MB.', 'cec' ),
			'bad_type'      => __( 'Please upload a JPG, PNG, GIF, or WEBP image.', 'cec' ),
			'upload_failed' => __( 'That photo could not be uploaded. Please try again.', 'cec' ),
		);
		return isset( $map[ $error_code ] ) ? $map[ $error_code ] : __( 'That photo could not be uploaded. Please try again.', 'cec' );
	}

	/**
	 * A <select> of every IANA timezone, grouped by continent the way PHP's
	 * own DateTimeZone::listIdentifiers() returns them — used everywhere an
	 * event or venue picks an explicit timezone. "Site Default" (empty
	 * value) is always the first option and always what's selected when no
	 * explicit value has been chosen, so leaving this alone never changes
	 * an event's current (already-correct) behavior.
	 */
	public static function timezone_select_html( $name, $selected ) {
		$groups = array();
		foreach ( DateTimeZone::listIdentifiers() as $tz ) {
			$parts  = explode( '/', $tz, 2 );
			$region = count( $parts ) > 1 ? $parts[0] : __( 'Other', 'cec' );
			$groups[ $region ][] = $tz;
		}

		ob_start();
		?>
		<select name="<?php echo esc_attr( $name ); ?>" id="<?php echo esc_attr( $name ); ?>">
			<option value="" <?php selected( '', $selected ); ?>>
				<?php
				/* translators: %s: the site's own configured timezone, e.g. "America/Chicago" */
				printf( esc_html__( 'Site Default (%s)', 'cec' ), esc_html( wp_timezone_string() ) );
				?>
			</option>
			<?php foreach ( $groups as $region => $zones ) : ?>
				<optgroup label="<?php echo esc_attr( $region ); ?>">
					<?php foreach ( $zones as $tz ) : ?>
						<option value="<?php echo esc_attr( $tz ); ?>" <?php selected( $tz, $selected ); ?>><?php echo esc_html( $tz ); ?></option>
					<?php endforeach; ?>
				</optgroup>
			<?php endforeach; ?>
		</select>
		<?php
		return ob_get_clean();
	}

	/**
	 * Static fallback share links for platforms with a reliable, universal
	 * web share-intent URL — these work with plain <a> tags, no JS required.
	 * Messenger/Snapchat/SMS deliberately excluded: none has a share URL
	 * that works reliably across both desktop and mobile without an
	 * installed app or a developer account, so those are only offered via
	 * the native OS share sheet (see the .cec-share-btn JS), which lists
	 * whatever's actually installed on the visitor's own device.
	 */
	/**
	 * 1.45.0: the event written up as plain text, ready to paste into a
	 * Facebook or FetLife event or post, or a Telegram message, so an
	 * organizer posts once here and copies it everywhere else. Plain text
	 * only (no HTML, no emoji) so it pastes cleanly on every platform.
	 */
	public static function post_text( $data ) {
		$lines = array( $data['title_plain'] );
		if ( 'scheduled' !== $data['event_status'] ) {
			$lines[] = strtoupper( $data['event_status'] ) . ( $data['event_status_note'] ? ': ' . self::plain_text( $data['event_status_note'] ) : '' );
		}
		$lines[] = '';
		$when = self::when_text( $data );
		if ( $when ) {
			/* translators: %s: date and time */
			$lines[] = sprintf( __( 'When: %s', 'cec' ), self::plain_text( $when ) );
		}
		$where = self::location_display( $data );
		$place = trim( $where['label'] . ( $where['detail'] ? ' — ' . $where['detail'] : '' ) );
		if ( 'in_person' === $data['location_mode'] && $data['address'] && $data['venue_name'] && false === strpos( $place, $data['address'] ) ) {
			$place .= ', ' . $data['address'];
		}
		/* translators: %s: place */
		$lines[] = sprintf( __( 'Where: %s', 'cec' ), self::plain_text( $place ) );
		$cost = self::admission_badge( array_merge( $data, array( 'event_status' => 'scheduled' ) ) );
		/* translators: %s: price, "Free" or "Price Not Posted" */
		$lines[] = sprintf( __( 'Cost: %s', 'cec' ), self::plain_text( $cost['label'] ) );
		$hosts = array();
		if ( $data['host_org_name'] ) {
			$hosts[] = self::plain_text( $data['host_org_name'] );
		}
		foreach ( (array) $data['partners'] as $partner ) {
			$name = is_array( $partner ) && isset( $partner['name'] ) ? self::plain_text( $partner['name'] ) : '';
			if ( $name && ! in_array( $name, $hosts, true ) ) {
				$hosts[] = $name;
			}
		}
		if ( $hosts ) {
			/* translators: %s: organizations and titleholders */
			$lines[] = sprintf( __( 'Hosted by: %s', 'cec' ), implode( ', ', $hosts ) );
		}
		$html        = $data['content'] ? $data['content'] : $data['excerpt'];
		$html        = preg_replace( array( '#</p>\s*#i', '#<br\s*/?>#i', '#</li>\s*#i' ), array( "\n\n", "\n", "\n" ), (string) $html );
		$description = self::plain_text( $html );
		$description = trim( preg_replace( "/\n{3,}/", "\n\n", str_replace( array( "\r\n", "\r" ), "\n", $description ) ) );
		if ( $description ) {
			if ( mb_strlen( $description ) > 1500 ) {
				$description = rtrim( mb_substr( $description, 0, 1497 ) ) . '…';
			}
			$lines[] = '';
			$lines[] = $description;
		}
		$lines[] = '';
		/* translators: %s: link to the event on this site */
		$lines[] = sprintf( __( 'Details and RSVP: %s', 'cec' ), $data['permalink'] );
		return implode( "\n", $lines );
	}

	/**
	 * 1.45.3: an end that's before its start. Both are site-local
	 * "Y-m-d\TH:i" strings, which sort as text.
	 * - Same date, earlier time ("7:00 PM to 12:00 AM" on one date): the
	 *   event runs past midnight, so the end is the next day.
	 * - An earlier date (a typo such as 2006 for 2026): no end is kept,
	 *   rather than an impossible one. The front-end forms refuse this
	 *   before sending (frontend.js), so this is only a safety net.
	 */
	public static function normalize_end( $start, $end ) {
		$start = (string) $start;
		$end   = (string) $end;
		if ( '' === $start || '' === $end || $end >= $start ) {
			return $end;
		}
		if ( substr( $end, 0, 10 ) === substr( $start, 0, 10 ) ) {
			$d = date_create( $end );
			return $d ? $d->modify( '+1 day' )->format( 'Y-m-d\TH:i' ) : $end;
		}
		return '';
	}

	/**
	 * 1.45.3: applies normalize_end() wherever an event's _cec_end is saved
	 * (the five edit forms, imports, repeating dates), via the
	 * add/update_post_metadata filters. Every form saves the start first.
	 */
	public static function filter_end_meta( $check, $object_id, $meta_key, $meta_value ) {
		static $busy = false;
		if ( '_cec_end' !== $meta_key || $busy || 'cec_event' !== get_post_type( $object_id ) ) {
			return $check;
		}
		$value = is_string( $meta_value ) ? $meta_value : '';
		// 1.47.1: "no end time" is stored as no _cec_end at all. Every list
		// and calendar query reads a missing end as "ends when it starts";
		// an empty string matched neither branch, so the event vanished
		// from the month view and upcoming lists (it still had its own page).
		if ( '' === trim( $value ) ) {
			$busy = true;
			delete_post_meta( $object_id, '_cec_end' );
			$busy = false;
			return true;
		}
		$fixed = self::normalize_end( get_post_meta( $object_id, '_cec_start', true ), $value );
		if ( $fixed === $value ) {
			return $check;
		}
		$busy = true;
		update_post_meta( $object_id, '_cec_end', $fixed );
		$busy = false;
		return true;
	}

	public static function share_links( $data ) {
		$url   = $data['permalink'];
		$title = $data['title_plain'];
		$text  = $title . ( $data['start_display'] ? ' — ' . $data['start_display'] : '' );

		// iOS and Android expect a different separator before the sms: body
		// param (& vs ?) — decided server-side from the request's own User
		// Agent so the link works with no JS, same as the others here.
		$is_ios  = isset( $_SERVER['HTTP_USER_AGENT'] ) && preg_match( '/iPad|iPhone|iPod/', $_SERVER['HTTP_USER_AGENT'] ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		$sms_sep = $is_ios ? '&' : '?';

		return array(
			'whatsapp' => 'https://wa.me/?text=' . rawurlencode( $text . ' ' . $url ),
			'telegram' => 'https://t.me/share/url?url=' . rawurlencode( $url ) . '&text=' . rawurlencode( $text ),
			'sms'      => 'sms:' . $sms_sep . 'body=' . rawurlencode( $text . ' ' . $url ),
			'facebook' => 'https://www.facebook.com/sharer/sharer.php?u=' . rawurlencode( $url ),
			'twitter'  => 'https://twitter.com/intent/tweet?text=' . rawurlencode( $text ) . '&url=' . rawurlencode( $url ),
			'email'    => 'mailto:?subject=' . rawurlencode( $title ) . '&body=' . rawurlencode( $text . "\n\n" . $url ),
		);
	}
}
